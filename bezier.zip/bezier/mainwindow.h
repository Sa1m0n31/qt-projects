#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include<QMainWindow>
#include<QImage>
#include<QPushButton>

#include "point.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    /* UI */
    QPushButton *addBtn, *removeBtn, *moveBtn;

    /* Variables and methods */
    QImage *img;
    int currentMode;
    int indexOfPointToRemove;
    QList<Point> bezierPoints, bezierPointsToMove;
    QList<bool> bezierPointsDeleted;

    void paintEvent(QPaintEvent *);

    void mousePressEvent(QMouseEvent *e);
    void drawPixel(Point p);
    void drawBezier(Point p1, Point p2, Point p3, Point p4);
    double slope(int x0, int x1, int y0, int y1);
    void drawLine(Point p1, Point p2);
    void drawPoint(Point p);
    Point detectPoint(Point p);
    void mouseMoveEvent(QMouseEvent *e);
    void drawPoint(Point p, bool deletePoint);
    void drawPoint(Point p, bool deletePoint, bool permanent);
    void clearTemporaryPoints();
    void drawPixel(Point p, QColor color);
    void drawLine(Point p1, Point p2, bool permanent);
    void drawBezier(QList<Point> bezierPoints, bool permanent);
    void clearWindow();
    void drawPoints();
public slots:
    void addMode();
    void removeMode();
    void moveMode();
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

#include "point3d.h"

Point3D::Point3D()
{

}

Point3D::Point3D(int x, int y, int z) {
    this->x = x;
    this->y = y;
    this->z = z;
}

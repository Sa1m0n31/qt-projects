#ifndef POINT3D_H
#define POINT3D_H


class Point3D
{
public:
    Point3D();
    Point3D(int x, int y, int z);
    int x, y, z;
};

#endif // POINT3D_H

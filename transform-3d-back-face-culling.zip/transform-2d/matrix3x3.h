#ifndef MATRIX3X3_H
#define MATRIX3X3_H


class Matrix3x3
{
public:
    Matrix3x3();
    double matrix[];
};

#endif // MATRIX3X3_H

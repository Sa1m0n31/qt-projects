#include "vector.h"

Vector::Vector()
{

}

Vector::Vector(int x, int y, int z) {
    this->x = x;
    this->y = y;
    this->z = z;
}

int Vector::scalarProduct(Vector u, Vector v) {
    return u.x * v.x + u.y * v.y + u.z * v.z;
}

Vector Vector::vectorProduct(Vector u, Vector v) {
    Vector result;
    result.x = u.y * v.z - v.y * u.z;
    result.y = v.x * u.z - u.x * v.z;
    result.z = u.x * v.y - v.x * u.y;

    return result;
}

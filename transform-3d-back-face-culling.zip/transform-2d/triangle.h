#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "point3d.h"


class Triangle
{
public:
    Triangle();
    Triangle(Point3D a, Point3D b, Point3D c);
    Point3D a, b, c;
};

#endif // TRIANGLE_H

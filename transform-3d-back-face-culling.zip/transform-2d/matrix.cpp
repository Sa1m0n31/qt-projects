#include "matrix.h"

Matrix::Matrix()
{

}

Matrix::Matrix(int rows, int cols) {
    this->rows = rows;
    this->cols = cols;
}

Matrix::Matrix(int rows, int cols, QVector<QVector<double> > *matrix) {
    this->rows = rows;
    this->cols = cols;
    this->matrix = *matrix;
}

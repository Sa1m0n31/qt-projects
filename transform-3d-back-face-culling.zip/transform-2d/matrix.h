#ifndef MATRIX_H
#define MATRIX_H

#include<QList>
#include<QVector>

class Matrix
{
public:
    Matrix();
    int rows, cols;
    QVector<QVector<double> > matrix;
    Matrix(int rows, int cols);
    Matrix(int rows, int cols, QVector<QVector<double> > *matrix);
};

#endif // MATRIX_H

#ifndef VECTOR_H
#define VECTOR_H


class Vector
{
public:
    Vector();
    int x, y, z;
    Vector(int x, int y, int z);
    int scalarProduct(Vector u, Vector v);
    Vector vectorProduct(Vector u, Vector v);
};

#endif // VECTOR_H

#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<cmath>

#include "mainwindow.h"
#include "matrix.h"
#include "point.h"
#include "point3d.h"
#include "color.h"
#include "triangle.h"

#include<QVector>
#include<QPainter>
#include<QImage>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /* Elementy UI */
    backgroundImg = new QImage(500, height(), QImage::Format_RGB32);

    backgroundImg->fill(QColor(0, 0, 0));

    transformXSlider = this->ui->transformX;
    transformYSlider = this->ui->transformY;
    transformZSlider = this->ui->transformZ;
    scaleXSlider = this->ui->scaleX;
    scaleYSlider = this->ui->scaleY;
    scaleZSlider = this->ui->scaleZ;
    rotateXSlider = this->ui->rotateX;
    rotateYSlider = this->ui->rotateY;
    rotateZSlider = this->ui->rotateZ;

    transformXSlider->setRange(0, 1000);
    transformYSlider->setRange(0, height() * 2);
    transformZSlider->setRange(0, 200);
    scaleXSlider->setRange(0, 200);
    scaleYSlider->setRange(0, 200);
    scaleZSlider->setRange(0, 200);
    rotateXSlider->setRange(0, 360);
    rotateYSlider->setRange(0, 360);
    rotateZSlider->setRange(0, 360);
    transformXSlider->setValue(0);
    transformYSlider->setValue(0);
    transformZSlider->setValue(100);
    scaleXSlider->setValue(50);
    scaleYSlider->setValue(50);
    scaleZSlider->setValue(0);

    transformXValue = 0;
    transformYValue = 0;
    transformZValue = 100;
    scaleXValue = 1;
    scaleYValue = 1;
    scaleZValue = 1;
    rotateXValue = 0;
    rotateYValue = 0;
    rotateZValue = 0;

    PERSPECTIVE = width() * 0.3;
    HEIGHT = height();
    HALF_WIDTH = backgroundImg->width() / 2;
    HALF_HEIGHT = backgroundImg->height() / 2;

    blue = Color(255, 0, 0);

    QObject::connect(transformXSlider, SIGNAL(valueChanged(int)), SLOT(handleTransformX(int)));
    QObject::connect(transformYSlider, SIGNAL(valueChanged(int)), SLOT(handleTransformY(int)));
    QObject::connect(transformZSlider, SIGNAL(valueChanged(int)), SLOT(handleTransformZ(int)));
    QObject::connect(scaleXSlider, SIGNAL(valueChanged(int)), SLOT(handleScaleX(int)));
    QObject::connect(scaleYSlider, SIGNAL(valueChanged(int)), SLOT(handleScaleY(int)));
    QObject::connect(scaleZSlider, SIGNAL(valueChanged(int)), SLOT(handleScaleZ(int)));
    QObject::connect(rotateXSlider, SIGNAL(valueChanged(int)), SLOT(handleRotateX(int)));
    QObject::connect(rotateYSlider, SIGNAL(valueChanged(int)), SLOT(handleRotateY(int)));
    QObject::connect(rotateZSlider, SIGNAL(valueChanged(int)), SLOT(handleRotateZ(int)));

    Point3D p3d = Point3D(-50, 50, -50);
    points3d[0] = p3d;
    p3d = Point3D(50, 50, -50);
    points3d[1] = p3d;
    p3d = Point3D(50, -50, -50);
    points3d[2] = p3d;
    p3d = Point3D(-50, -50, -50);
    points3d[3] = p3d;
    p3d = Point3D(-50, 50, 50);
    points3d[4] = p3d;
    p3d = Point3D(50, 50, 50);
    points3d[5] = p3d;
    p3d = Point3D(50, -50, 50);
    points3d[6] = p3d;
    p3d = Point3D(-50, -50, 50);
    points3d[7] = p3d;

    /* Rysowanie szescianu */
    Point p = projection(-50, 50, -50);
    points[0] = p;
    drawPixel(p.x, p.y, Color(0, 255, 0));
    p = projection(50, 50, -50);
    points[1] = p;
    drawPixel(p.x, p.y, Color(0, 255, 0));
    p = projection(50, -50, -50);
    points[2] = p;
    drawPixel(p.x, p.y, Color(0, 255, 0));
    p = projection(-50, -50, -50);
    points[3] = p;
    drawPixel(p.x, p.y, Color(0, 255, 0));
    p = projection(-80, 20, 50);
    points[4] = p;
    drawPixel(p.x, p.y, Color(0, 255, 0));
    p = projection(20, 20, 50);
    points[5] = p;
    drawPixel(p.x, p.y, Color(0, 255, 0));
    p = projection(20, -80, 50);
    points[6] = p;
    drawPixel(p.x, p.y, Color(0, 255, 0));
    p = projection(-80, -80, 50);
    points[7] = p;
    drawPixel(p.x, p.y, Color(0, 255, 0));

    drawLine(points[0], points[1]);
    drawLine(points[3], points[2]);
    drawLine(points[4], points[5]);
    drawLine(points[7], points[6]);
    drawLine(points[4], points[7]);
    drawLine(points[5], points[6]);
    drawLine(points[0], points[3]);
    drawLine(points[1], points[2]);
    drawLine(points[0], points[4]);
    drawLine(points[1], points[5]);
    drawLine(points[3], points[7]);
    drawLine(points[2], points[6]);

    /* Dodajemy 12 trojkatow do tablicy */
    triangles[0] = Triangle(points3d[0], points3d[1], points3d[2]);
    triangles[1] = Triangle(points3d[0], points3d[2], points3d[3]);

    triangles[2] = Triangle(points3d[4], points3d[6], points3d[5]);
    triangles[3] = Triangle(points3d[4], points3d[7], points3d[6]);

    triangles[4] = Triangle(points3d[7], points3d[0], points3d[4]);
    triangles[5] = Triangle(points3d[3], points3d[0], points3d[7]);

    triangles[6] = Triangle(points3d[1], points3d[5], points3d[6]);
    triangles[7] = Triangle(points3d[1], points3d[6], points3d[2]);

    triangles[8] = Triangle(points3d[0], points3d[4], points3d[5]);
    triangles[9] = Triangle(points3d[0], points3d[5], points3d[1]);

    triangles[10] = Triangle(points3d[2], points3d[6], points3d[7]);
    triangles[11] = Triangle(points3d[3], points3d[2], points3d[7]);

    allOperations();
}

/* Ukrywanie niewidocznych scian */
bool MainWindow::isHidden(Triangle t) {
    Point a = projection(t.a);
    Point b = projection(t.b);
    Point c = projection(t.c);

    int a_y = b.y - a.y;
    int a_x = b.x - a.x;
    int b_x = c.x - a.x;
    int b_y = c.y - a.y;

    return a_y*b_x - a_x*b_y < 0;
}

int MainWindow::findMostLeft(Point3D vertices[12]) {
    int i, mostLeft = 500;
    Point p;
    for(i=0; i<12; i++) {
        p = projection(vertices[i].x, vertices[i].y, vertices[i].z);
        if(p.x < mostLeft) {
            mostLeft = p.x;
        }
    }
    return mostLeft;
}

int MainWindow::findMostRight(Point3D vertices[12]) {
    int i, mostRight = -500;
    Point p;
    for(i=0; i<12; i++) {
        p = projection(vertices[i].x, vertices[i].y, vertices[i].z);
        if(p.x > mostRight) {
            mostRight = p.x;
        }
    }
    return mostRight;
}

int MainWindow::findMostTop(Point3D vertices[12]) {
    int i, mostTop = 500;
    Point p;
    for(i=0; i<12; i++) {
        p = projection(vertices[i].x, vertices[i].y, vertices[i].z);
        if(p.y < mostTop) {
            mostTop = p.y;
        }
    }
    return mostTop;
}

int MainWindow::findMostBottom(Point3D vertices[12]) {
    int i, mostBottom = -500;
    Point p;
    for(i=0; i<12; i++) {
        p = projection(vertices[i].x, vertices[i].y, vertices[i].z);
        if(p.y > mostBottom) {
            mostBottom = p.y;
        }
    }
    return mostBottom;
}

void MainWindow::texturing(Point3D vertices[12]) {
    int i, j, k;

    /* Optymalizacja - znajdujemy skrajne wierzcholki szescianu (najbardziej na lewo, prawo, gore, dol) i przeszukujemy tylko te znajdujace sie w zdefiniowanym w ten sposob czworokacie */
    int left = findMostLeft(vertices);
    int right = findMostRight(vertices);
    int top = findMostTop(vertices);
    int bottom = findMostBottom(vertices);

    /* Dla kazdego trojkata*/
    for(k=0; k<12; k++) {
        /* Jesli jest widoczny (back face culling) */
        if(isHidden(triangles[k])) {
            continue;
        }

        /* Dla kazdego piksela na canvasie obliczamy wspolrzedne barycentryczne i ewentualnie zamalowujemy piksel */
        for(i=top; i<bottom; i++) {
            for(j=left; j<right; j++) {
                barycentricCoordinates(triangles[k], Point(j, i));
            }
        }
    }
}

void MainWindow::barycentricCoordinates(Triangle triangle, Point p) {
    int x = p.x, y = p.y;
    int x_a, y_a, x_b, y_b, x_c, y_c;
    float u, v, w;
    Point point;

    point = projection(triangle.a);
    x_a = point.x;
    y_a = point.y;
    point = projection(triangle.b);
    x_b = point.x;
    y_b = point.y;
    point = projection(triangle.c);
    x_c = point.x;
    y_c = point.y;

    v = (float) (((x - x_a) * (y_c - y_a) - (y - y_a) * (x_c - x_a)))
            /
            (float) (((x_b - x_a) * (y_c - y_a) - (y_b - y_a) * (x_c - x_a)));

    w = (float) (((x_b - x_a) * (y - y_a) - (y_b - y_a) * (x - x_a)))
            /
            (float) (((x_b - x_a) * (y_c - y_a) - (y_b - y_a) * (x_c - x_a)));
    u = 1 - v - w;

   /* Jesli punkt znajduje sie wewnatrz czarnego trojkata to go zamaluj */
   if((u > 0)&&(v > 0)&&(w > 0)&&(u < 1)&&(v < 1)&&(w < 1)) {
       /* Kolorujemy punkt */
       if((y > 0)&&(y < HEIGHT)) {
           uchar *ptr = backgroundImg->scanLine(y);
           if(ptr[4*x+1] == 0) {
              drawPixel(x, y, blue);
           }
       }
   }
}

Point MainWindow::projection(int x, int y, int z) {
    float scaleProjected = PERSPECTIVE / (PERSPECTIVE + z);
    int newX = floor(x * scaleProjected) + HALF_WIDTH;
    int newY = floor(y * scaleProjected) + HALF_HEIGHT;

    Point newPoint(newX, newY);
    return newPoint;
}

Point MainWindow::projection(Point3D three) {
    float scaleProjected = PERSPECTIVE / (PERSPECTIVE + three.z);
    int newX = floor(three.x * scaleProjected) + HALF_WIDTH;
    int newY = floor(three.y * scaleProjected) + HALF_HEIGHT;

    Point newPoint(newX, newY);
    return newPoint;
}

double MainWindow::slope(int x0, int x1, int y0, int y1) {
    return (double) ((y1 - y0) / (double) (x1 - x0));
}

void MainWindow::drawLine(Point p1, Point p2) {
    int x0 = p1.x;
    int x1 = p2.x;
    int y0 = p1.y;
    int y1 = p2.y;
    int x, y;
    if(x1 != x0) {
        double m = slope(x0, x1, y0, y1);
        if(abs(m) > 1) {
            /* Kat nachylenia > 45 stopni - zamieniamy kolejnosc wspolrzednych w obu punktach */
            double x = x0;
            if(y1 > y0) {
                for(y=y0; y<=y1; y++) {
                    drawPixel((int) floor(x), y, Color(255, 255, 255));

                    x += (double) 1/m;
                }
            }
            else {
                for(y=y0; y>=y1; y--) {
                    drawPixel((int) floor(x), y, Color(255, 255, 255));

                    x -= (double) 1/m;
                }
            }
        }
        else {
            double y = y0;
            if(x1 > x0) {
                for(x=x0; x<=x1; x++) {
                    drawPixel(x, (int) floor(y+0.5), Color(255, 255, 255));

                    y += m;
                }
            }
            else {
                for(x=x0; x>=x1; x--) {
                    drawPixel(x, (int) floor(y+0.5), Color(255, 255, 255));

                    y -= m;
                }
            }
        }
    }
    else {
        /* Pionowy odcinek (rownanie x = a) */
        if(y1 > y0) {
            for(y=y0; y<=y1; y++) {
                drawPixel(x0, (int) floor(y+0.5), Color(255, 255, 255));
            }
        }
        else {
            for(y=y1; y<=y0; y++) {
                drawPixel(x0, (int) floor(y+0.5), Color(255, 255, 255));
            }
        }
    }

}

void MainWindow::handleTransformX(int v) {
    transformXValue = v;
    allOperations();
}

void MainWindow::handleTransformY(int v) {
    transformYValue = v;
    allOperations();
}

void MainWindow::handleTransformZ(int z) {
    transformZValue = z;
    allOperations();
}

void MainWindow::handleScaleX(int v) {
    scaleXValue = (float) v / (float) 50;
    allOperations();
}

void MainWindow::handleScaleY(int v) {
    scaleYValue = (float) v / (float) 50;
    allOperations();
}

void MainWindow::handleScaleZ(int v) {
    scaleZValue = (float) v / (float) 50;
    allOperations();
}

void MainWindow::handleRotateX(int v) {
    rotateXValue = v;
    allOperations();
}

void MainWindow::handleRotateY(int v) {
    rotateYValue = v;
    allOperations();
}

void MainWindow::handleRotateZ(int v) {
    rotateZValue = v;
    allOperations();
}

void MainWindow::clearImage() {
    int i, j;
    for(i=0; i<backgroundImg->height(); i++) {
        uchar *ptr = backgroundImg->scanLine(i);
        for(j=0; j<backgroundImg->width(); j++) {
            ptr[4*j] = 0;
            ptr[4*j+1] = 0;
            ptr[4*j+2] = 0;
            ptr[4*j+3] = 255;
        }
    }
    update();
}

void MainWindow::allOperations() {
    int i, x, y, z;
    Point newPoint;
    Point3D tmp3dPoints[8];
    Color color = Color(255, 0, 0);
    double coordinatesMatrix[4][1];
    double scaleMatrix[4][4], rotateXMatrix[4][4], rotateYMatrix[4][4], rotateZMatrix[4][4], transformMatrix[4][4];

    float cosXAlpha = std::cos((double) rotateXValue * M_PI / (double) 180);
    float sinXAlpha = std::sin((double) rotateXValue * M_PI / (double) 180);

    float cosYAlpha = std::cos((double) rotateYValue * M_PI / (double) 180);
    float sinYAlpha = std::sin((double) rotateYValue * M_PI / (double) 180);

    float cosZAlpha = std::cos((double) rotateZValue * M_PI / (double) 180);
    float sinZAlpha = std::sin((double) rotateZValue * M_PI / (double) 180);

    scaleMatrix[0][0] = scaleXValue;
    scaleMatrix[0][1] = 0;
    scaleMatrix[0][2] = 0;
    scaleMatrix[0][3] = 0;
    scaleMatrix[1][0] = 0;
    scaleMatrix[1][1] = scaleYValue;
    scaleMatrix[1][2] = 0;
    scaleMatrix[1][3] = 0;
    scaleMatrix[2][0] = 0;
    scaleMatrix[2][1] = 0;
    scaleMatrix[2][2] = scaleZValue;
    scaleMatrix[2][3] = 0;
    scaleMatrix[3][0] = 0;
    scaleMatrix[3][1] = 0;
    scaleMatrix[3][2] = 0;
    scaleMatrix[3][3] = 1;

    rotateXMatrix[0][0] = 1;
    rotateXMatrix[0][1] = 0;
    rotateXMatrix[0][2] = 0;
    rotateXMatrix[0][3] = 0;
    rotateXMatrix[1][0] = 0;
    rotateXMatrix[1][1] = cosXAlpha;
    rotateXMatrix[1][2] = -sinXAlpha;
    rotateXMatrix[1][3] = 0;
    rotateXMatrix[2][0] = 0;
    rotateXMatrix[2][1] = sinXAlpha;
    rotateXMatrix[2][2] = cosXAlpha;
    rotateXMatrix[2][3] = 0;
    rotateXMatrix[3][0] = 0;
    rotateXMatrix[3][1] = 0;
    rotateXMatrix[3][2] = 0;
    rotateXMatrix[3][3] = 1;

    rotateYMatrix[0][0] = cosYAlpha;
    rotateYMatrix[0][1] = 0;
    rotateYMatrix[0][2] = sinYAlpha;
    rotateYMatrix[0][3] = 0;
    rotateYMatrix[1][0] = 0;
    rotateYMatrix[1][1] = 1;
    rotateYMatrix[1][2] = 0;
    rotateYMatrix[1][3] = 0;
    rotateYMatrix[2][0] = -sinYAlpha;
    rotateYMatrix[2][1] = 0;
    rotateYMatrix[2][2] = cosYAlpha;
    rotateYMatrix[2][3] = 0;
    rotateYMatrix[3][0] = 0;
    rotateYMatrix[3][1] = 0;
    rotateYMatrix[3][2] = 0;
    rotateYMatrix[3][3] = 1;

    rotateZMatrix[0][0] = cosZAlpha;
    rotateZMatrix[0][1] = -sinZAlpha;
    rotateZMatrix[0][2] = 0;
    rotateZMatrix[0][3] = 0;
    rotateZMatrix[1][0] = sinZAlpha;
    rotateZMatrix[1][1] = cosZAlpha;
    rotateZMatrix[1][2] = 0;
    rotateZMatrix[1][3] = 0;
    rotateZMatrix[2][0] = 0;
    rotateZMatrix[2][1] = 0;
    rotateZMatrix[2][2] = 1;
    rotateZMatrix[2][3] = 0;
    rotateZMatrix[3][0] = 0;
    rotateZMatrix[3][1] = 0;
    rotateZMatrix[3][2] = 0;
    rotateZMatrix[3][3] = 1;

    transformMatrix[0][0] = 1;
    transformMatrix[0][1] = 0;
    transformMatrix[0][2] = 0;
    transformMatrix[0][3] = transformXValue;
    transformMatrix[1][0] = 0;
    transformMatrix[1][1] = 1;
    transformMatrix[1][2] = 0;
    transformMatrix[1][3] = transformYValue;
    transformMatrix[2][0] = 0;
    transformMatrix[2][1] = 0;
    transformMatrix[2][2] = 1;
    transformMatrix[2][3] = transformZValue;
    transformMatrix[3][0] = 0;
    transformMatrix[3][1] = 0;
    transformMatrix[3][2] = 0;
    transformMatrix[3][3] = 1;

    coordinatesMatrix[0][0] = 0;
    coordinatesMatrix[1][0] = 0;
    coordinatesMatrix[2][0] = 0;
    coordinatesMatrix[3][0] = 1;

    clearImage();

    /* Przechodzimy przez kazdy z osmiu wierzcholkow i przeksztalcamy go */
    for(i=0; i<8; i++) {
        coordinatesMatrix[0][0] = points3d[i].x;
        coordinatesMatrix[1][0] = points3d[i].y;
        coordinatesMatrix[2][0] = points3d[i].z;

        multiplyMatrices(scaleMatrix, coordinatesMatrix);
        multiplyMatrices(rotateZMatrix, tmpResult);
        multiplyMatrices(rotateXMatrix, tmpResult);
        multiplyMatrices(rotateYMatrix, tmpResult);
        multiplyMatrices(transformMatrix, tmpResult);

        x = tmpResult[0][0];
        y = tmpResult[1][0];
        z = tmpResult[2][0];

        tmp3dPoints[i] = Point3D(x, y, z);

        newPoint = projection(x, y, z);

        drawPixel(newPoint.x, newPoint.y, color);
    }

    drawLine(projection(tmp3dPoints[0]), projection(tmp3dPoints[1]));
    drawLine(projection(tmp3dPoints[3]), projection(tmp3dPoints[2]));
    drawLine(projection(tmp3dPoints[4]), projection(tmp3dPoints[5]));
    drawLine(projection(tmp3dPoints[7]), projection(tmp3dPoints[6]));
    drawLine(projection(tmp3dPoints[4]), projection(tmp3dPoints[7]));
    drawLine(projection(tmp3dPoints[5]), projection(tmp3dPoints[6]));
    drawLine(projection(tmp3dPoints[0]), projection(tmp3dPoints[3]));
    drawLine(projection(tmp3dPoints[1]), projection(tmp3dPoints[2]));
    drawLine(projection(tmp3dPoints[0]), projection(tmp3dPoints[4]));
    drawLine(projection(tmp3dPoints[1]), projection(tmp3dPoints[5]));
    drawLine(projection(tmp3dPoints[3]), projection(tmp3dPoints[7]));
    drawLine(projection(tmp3dPoints[2]), projection(tmp3dPoints[6]));

    /* Dodajemy 12 trojkatow do tablicy */
    triangles[0] = Triangle(tmp3dPoints[0], tmp3dPoints[1], tmp3dPoints[2]);
    triangles[1] = Triangle(tmp3dPoints[0], tmp3dPoints[2], tmp3dPoints[3]);

    triangles[2] = Triangle(tmp3dPoints[4], tmp3dPoints[6], tmp3dPoints[5]);
    triangles[3] = Triangle(tmp3dPoints[4], tmp3dPoints[7], tmp3dPoints[6]);

    triangles[4] = Triangle(tmp3dPoints[0], tmp3dPoints[7], tmp3dPoints[4]);
    triangles[5] = Triangle(tmp3dPoints[0], tmp3dPoints[3], tmp3dPoints[7]);

    triangles[6] = Triangle(tmp3dPoints[1], tmp3dPoints[5], tmp3dPoints[6]);
    triangles[7] = Triangle(tmp3dPoints[1], tmp3dPoints[6], tmp3dPoints[2]);

    triangles[8] = Triangle(tmp3dPoints[0], tmp3dPoints[4], tmp3dPoints[5]);
    triangles[9] = Triangle(tmp3dPoints[0], tmp3dPoints[5], tmp3dPoints[1]);

    triangles[10] = Triangle(tmp3dPoints[2], tmp3dPoints[6], tmp3dPoints[7]);
    triangles[11] = Triangle(tmp3dPoints[3], tmp3dPoints[2], tmp3dPoints[7]);

    texturing(tmp3dPoints);

    update();

}

void MainWindow::drawPixel(int x, int y, Color color) {
    if((x < 0)||(y < 0)||(x >= backgroundImg->width())||(y >= backgroundImg->height())) return;

    uchar *ptr = backgroundImg->scanLine(y);

    ptr[4*x] = color.b;
    ptr[4*x + 1] = color.g;
    ptr[4*x + 2] = color.r;
    ptr[4*x + 3] = 255;
}

/* Metoda mnozaca macierze 4x4 i 4x1 */
void MainWindow::multiplyMatrices(double matrixA[][4], double matrixB[][1]) {
    int i, j, k;
    double value;
    double localCopyOfTmpResult[4][1];

    for(i=0; i<4; i++) { // Wiersze pierwszej macierzy
        for(j=0; j<1; j++) { // Kolumny drugiej macierzy
            value = 0;
            for(k=0; k<4; k++) { // Wiersze drugiej macierzy
                value += matrixA[i][k] * matrixB[k][j];
            }
            localCopyOfTmpResult[i][j] = value;
        }
    }

    tmpResult[0][0] = localCopyOfTmpResult[0][0];
    tmpResult[1][0] = localCopyOfTmpResult[1][0];
    tmpResult[2][0] = localCopyOfTmpResult[2][0];
    tmpResult[3][0] = localCopyOfTmpResult[3][0];
}

void MainWindow::paintEvent(QPaintEvent *event) {
    QPainter p(this);
    p.fillRect(0, 0, 500, height(), QColor(50, 50, 50));
    p.drawImage(0, 0, *backgroundImg);


}

MainWindow::~MainWindow()
{
    delete ui;
}


#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "matrix.h"
#include "color.h"
#include "point.h"
#include "point3d.h"
#include "triangle.h"

#include<QMainWindow>
#include<QSlider>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QImage *backgroundImg;
    QSlider *transformXSlider, *transformYSlider, *transformZSlider, *scaleXSlider, *scaleYSlider, *scaleZSlider, *rotateXSlider, *rotateYSlider, *rotateZSlider;
    void paintEvent(QPaintEvent *event);

    int transformXValue, transformYValue, transformZValue, rotateXValue, rotateYValue, rotateZValue;
    float scaleXValue, scaleYValue, scaleZValue;
    Color blue;

    int HEIGHT, HALF_WIDTH, HALF_HEIGHT;
    float PERSPECTIVE;

    double tmpResult[4][1];
    Point points[8];
    Point3D points3d[8];
    Triangle triangles[12];

    Color getPixelColor(int x, int y);
    void drawPixel(int x, int y, Color color);
    void allOperations();
    void multiplyMatrices(double matrixA[][4], double matrixB[][1]);
    Point projection(int x, int y, int z);
    double slope(int x0, int x1, int y0, int y1);
    void drawLine(bool permanent);
    void drawLine(Point p1, Point p2);
    Point projection(Point3D three);
    void clearImage();
    void barycentricCoordinates(Triangle triangle, Point p);
    int findMostLeft(Point3D vertices);
    void texturing(Point3D vertices[]);
    int findMostLeft(Point3D vertices[]);
    int findMostBottom(Point3D vertices[]);
    int findMostTop(Point3D vertices[]);
    int findMostRight(Point3D vertices[]);
    bool isHidden(Triangle t);
public slots:
    void handleTransformX(int v);
    void handleTransformY(int v);
    void handleScaleX(int v);
    void handleScaleY(int v);
    void handleTransformZ(int z);
    void handleRotateY(int v);
    void handleRotateX(int v);
    void handleRotateZ(int v);
    void handleScaleZ(int z);
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

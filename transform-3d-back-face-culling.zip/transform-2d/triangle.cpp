#include "triangle.h"

Triangle::Triangle()
{

}

Triangle::Triangle(Point3D a, Point3D b, Point3D c) {
    this->a = a;
    this->b = b;
    this->c = c;
}

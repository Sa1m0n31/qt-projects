#ifndef COLOR_H
#define COLOR_H


class Color
{
public:
    Color();
    Color(int r, int g, int b);
    int r, g, b;
};

#endif // COLOR_H

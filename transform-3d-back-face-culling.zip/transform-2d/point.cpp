#include "point.h"

Point::Point()
{

}

Point::Point(int x, int y) {
    this->x = x;
    this->y = y;
}

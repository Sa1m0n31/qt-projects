#include "color.h"

Color::Color()
{

}

Color::Color(int r, int g, int b) {
    this->r = r;
    this->g = g;
    this->b = b;
}

#include "line.h"

Line::Line()
{

}

Line::Line(int ax, int ay, int bx, int by) {
    this->ax = ax;
    this->ay = ay;
    this->bx = bx;
    this->by = by;
}

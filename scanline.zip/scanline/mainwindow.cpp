#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<algorithm>

#include<QList>
#include<QPainter>
#include<QMouseEvent>

#include "point.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /* Ustawiamy nasze plotno do rysowania */
    img = QImage(width(), height(), QImage::Format_RGB32);

    drawing = 0;

    update();
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(255, 255, 255));
    p.drawImage(0, 0, img);
}

/* Czyszczenie ekranu */
void MainWindow::clearWindow() {
    for(int i=0; i<height(); i++) {
        uchar *p = img.scanLine(i);
        for(int j=0; j<width(); j++) {
            if(p[j*4+2] != 254) {
                p[j*4] = 0;
                p[j*4+1] = 0;
                p[j*4+2] = 0;
                p[j*4+3] = 255;
            }
        }
    }
}

/* Rozpoczecie rysowania odcinka */
void MainWindow::mousePressEvent(QMouseEvent *e) {
    if(drawing) {
        if(drawing == 2) {
            x0 = x1;
            y0 = y1;
        }
        else drawing = 2;

        QPointF pt = e->position();
        x1 = floor(pt.x());
        y1 = floor(pt.y());

        Point *b = new Point(x1, y1);
        points << *b;

        drawLine(*new Point(x0, y0), *b);
        update();
    }
    else {
        clearWindow();
        update();

        QPointF pt = e->position();
        x0 = floor(pt.x());
        y0 = floor(pt.y());

        Point *a = new Point(x0, y0);
        points << *a;

        drawing = 1;
    }
}

void MainWindow::mouseDoubleClickEvent( QMouseEvent * e )
{
    scanLine(points);
    update();
    drawing = 0;
    points.clear();
}

void MainWindow::drawPixel(int x, int y) {
    /* Sprawdzamy czy znajdujemy sie wewnatrz okna */
    if(x > img.width() || x < 0 || y > img.height() || y < 0) {
        return;
    }

    /* Pobieramy wskaznik do pierwszego piksela y-tego wiersza */
    uchar *p = img.scanLine(y);

    /* Kolorujemy x-ty piksel w y-tym wierszu */
    p[x*4] = 255;
    p[x*4+1] = 255;
    p[x*4+2] = 255;
    p[x*4+3] = 255;
}

void MainWindow::drawLine(Point a, Point b) {
    int x, y;
    int x0 = a.x;
    int x1 = b.x;
    int y0 = a.y;
    int y1 = b.y;

    if(x1 != x0) {
            double m = slope(a, b);
            if(abs(m) > 1) {
                /* Kat nachylenia > 45 stopni - zamieniamy kolejnosc wspolrzednych w obu punktach */
                double x = x0;
                if(y1 > y0) {
                    for(y=y0; y<=y1; y++) {
                        drawPixel((int) floor(x), y);

                        x += (double) 1/m;
                    }
                }
                else {
                    for(y=y0; y>=y1; y--) {
                        drawPixel((int) floor(x), y);

                        x -= (double) 1/m;
                    }
                }
            }
            else {
                double y = y0;
                if(x1 > x0) {
                    for(x=x0; x<=x1; x++) {
                       drawPixel(x, (int) floor(y+0.5));

                        y += m;
                    }
                }
                else {
                    for(x=x0; x>=x1; x--) {
                       drawPixel(x, (int) floor(y+0.5));

                        y -= m;
                    }
                }
            }
        }
        else {
            /* Pionowy odcinek (rownanie x = a) */
            if(y1 > y0) {
                for(y=y0; y<=y1; y++) {
                   drawPixel(x0, (int) floor(y+0.5));
                }
            }
            else {
                for(y=y1; y<=y0; y++) {
                    drawPixel(x0, (int) floor(y+0.5));
                }
            }
        }
}

double MainWindow::slope(Point a, Point b) {
    if(b.x - a.x != 0) return (double) ((b.y - a.y) / (double) (b.x - a.x));
    return 0;
}

void MainWindow::scanLine(QList<Point> points) {
    int y, i, x, j;

    points.removeLast();

    for(y=0; y<img.height()-1; y++) {
        QList<int> pointsThatIntersect;

        for(i=0; i<points.size()-1; i++) {
            Point currentPointA = points[i+1];
            Point currentPointB = points[i];


            /* 1A - Sprawdzenie czy prosta pozioma y przecina sie z odcinkiem */
            if(y > currentPointA.y) {
                if(y <= currentPointB.y) {
                    /* y wiekszy od Ay i mniejszy od By - prosta przecina odcinek */
                    if(currentPointB.y - currentPointA.y != 0) {
                        x = floor(currentPointA.x + (y - currentPointA.y) * (double) (currentPointB.x - currentPointA.x) / (double) (currentPointB.y - currentPointA.y));
                        pointsThatIntersect << x;
                    }
                    else pointsThatIntersect << currentPointA.x;
                }               
            }
            else {
                if(y > currentPointB.y) {
                    /* y mniejszy od Ay i wiekszy od By - prosta przecina odcinek */
                    if(currentPointB.y - currentPointA.y != 0) {
                        x = floor(currentPointA.x + (y - currentPointA.y) * (double) (currentPointB.x - currentPointA.x) / (double) (currentPointB.y - currentPointA.y));
                        pointsThatIntersect << x;

                    }
                    else pointsThatIntersect << currentPointA.x;
                }
            }
        }
        Point currentPointA = points[0];
        Point currentPointB = points[i];

        /* 1A - Sprawdzenie czy prosta pozioma y przecina sie z odcinkiem */
        if(y > currentPointA.y) {
            if(y <= currentPointB.y) {
                /* y wiekszy od Ay i mniejszy od By - prosta przecina odcinek */
                if(currentPointB.y - currentPointA.y != 0) {
                    x = floor(currentPointA.x + (y - currentPointA.y) * (double) (currentPointB.x - currentPointA.x) / (double) (currentPointB.y - currentPointA.y));
                    pointsThatIntersect << x;
                }
                else pointsThatIntersect << currentPointA.x;
            }
        }
        else {
            if(y > currentPointB.y) {
                /* y mniejszy od Ay i wiekszy od By - prosta przecina odcinek */
                if(currentPointB.y - currentPointA.y != 0) {
                    x = floor(currentPointA.x + (y - currentPointA.y) * (double) (currentPointB.x - currentPointA.x) / (double) (currentPointB.y - currentPointA.y));
                    pointsThatIntersect << x;
                }
                else pointsThatIntersect << currentPointA.x;
            }
        }

        /* 2. Posortuj punkty przeciecia */
        if(pointsThatIntersect.size() > 0) std::sort(pointsThatIntersect.begin(), pointsThatIntersect.end());

        /* 3. Zamaluj wszystkie segmenty od parzystych do nieparzystych przeciec */
        for(i=0; i<pointsThatIntersect.size()-1; i++) {

            if(i % 2 == 0) {
                /* Jesli parzysty punkt przeciecia - koloruj az do napotkania nieparzystego punktu przeciecia */
                for(j=pointsThatIntersect[i]; j<pointsThatIntersect[i+1]; j++) {
                    drawPixel(j, y);
                }
            }

        }

        /* 4. Wyczysc tablice */
        pointsThatIntersect.clear();

    }
}




MainWindow::~MainWindow()
{
    delete ui;
}


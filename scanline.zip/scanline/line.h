#ifndef LINE_H
#define LINE_H


class Line
{
public:
    Line();
    Line(int ax, int ay, int bx, int by);
    int ax, ay, bx, by;
    double slope;
};

#endif // LINE_H

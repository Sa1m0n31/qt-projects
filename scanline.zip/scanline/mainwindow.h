#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "point.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    int x0, y0, x1, y1;
    int drawing;
    QImage img;
    QList<Point> points;

    void scanLine(QList<Point> points);
    void drawLine(Point a, Point b);
    double slope(Point a, Point b);
    void drawPixel(int x, int y);
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *e);
    void clearWindow();
    void mouseDoubleClickEvent(QMouseEvent *e);
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

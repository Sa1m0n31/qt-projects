Program działa w następujący sposób:
- użytkownik wybiera pierwszy wierzchołek wielokąta kliknięciem
- następnie zaznacza kolejne wierzchołki wielokąta pojedynczymi kliknięciami
- podwójne kliknięcie oznacza koniec rysowania wielokąta i "uzupełnienie" go automatycznie linią prostą między ostatnim a pierwszym wierzchołkiem
- następnie narysowany wielokąt zamalowywany jest na biało algorytmem scanline
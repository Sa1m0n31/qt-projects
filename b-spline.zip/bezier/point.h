#ifndef POINT_H
#define POINT_H


class Point
{
public:
    int x, y;
    Point();
    Point(int x, int y);
};

#endif // POINT_H

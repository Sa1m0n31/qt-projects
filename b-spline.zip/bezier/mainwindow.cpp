#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<cmath>

#include<QPainter>
#include<QPaintEvent>
#include<QPointF>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    addBtn = this->ui->addBtn;
    removeBtn = this->ui->removeBtn;
    moveBtn = this->ui->moveBtn;

    img = new QImage(500, height(), QImage::Format_RGB32);
    currentMode = 0;

    /* Signals */
    QObject::connect(addBtn, &QPushButton::released, this, &MainWindow::addMode);
    QObject::connect(removeBtn, &QPushButton::released, this, &MainWindow::removeMode);
    QObject::connect(moveBtn, &QPushButton::released, this, &MainWindow::moveMode);
}

void MainWindow::addMode() {
    currentMode = 0;
}

void MainWindow::removeMode() {
    currentMode = 1;
}

void MainWindow::moveMode() {
    currentMode = 2;
}

void MainWindow::clearWindow() {
    for(int i=0; i<img->height(); i++) {
        uchar *p = img->scanLine(i);
        for(int j=0; j<img->width(); j++) {
            if(p[j*4+2] == 255) {
                p[j*4] = 0;
                p[j*4+1] = 0;
                p[j*4+2] = 0;
                p[j*4+3] = 255;
            }
        }
    }
    update();
}

void MainWindow::mousePressEvent(QMouseEvent *e) {
    QPointF position = e->position();
    int x = floor(position.x());
    int y = floor(position.y());
    int bezierSize;

    if(currentMode == 0) {
        /* DODAWANIE PUNKTOW KONTROLNYCH */

        /* Dodajemy punkt kontrolny do listy */
        Point *newPoint = new Point(x, y);
        bezierPoints.append(*newPoint);
        bezierPointsDeleted.append(false);
        drawPoint(*newPoint, false, false);

        /* Jesli liczba punktow jest wieksza od 3 - rysujemy krzywa B-sklejana */
        bezierSize = bezierPoints.size();
        if(bezierSize >- 4) {
            drawBspline(bezierPoints, true);
        }
    }
    else if(currentMode == 1) {
        /* USUWANIE PUNKTW KONTROLNYCH */
        Point pointToRemove = detectPoint(*new Point(x, y));

        bezierPointsDeleted[indexOfPointToRemove] = true;
        drawPoint(pointToRemove, true, true);
    }
    else {
        /* PRZESUWANIE PUNKTOW KONTROLNYCH */
        Point pointToMove = detectPoint(*new Point(x, y));
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *e) {
    if(currentMode == 2) {
        /* PRZESUWANIE PUNKTOW KONTROLNYCH */
        QPointF position = e->position();
        int x = floor(position.x());
        int y = floor(position.y());

        clearTemporaryPoints();
        drawPoint(*new Point(x, y), false, false);

        bezierPoints[indexOfPointToRemove].x = x;
        bezierPoints[indexOfPointToRemove].y = y;

        /* Rysujemy krzywe */
        clearWindow();
        drawBspline(bezierPoints, true);
        drawPoints();
    }
}

void MainWindow::clearTemporaryPoints() {
    for(int i=0; i<img->height(); i++) {
        uchar *p = img->scanLine(i);
        for(int j=0; j<img->width(); j++) {
            if(p[j*4+1] == 254) {
                p[j*4] = 0;
                p[j*4+1] = 0;
                p[j*4+2] = 0;
                p[j*4+3] = 255;
            }
        }
    }
    update();
}

void MainWindow::drawPoints() {
    int i;
    for(i=0; i<bezierPoints.size(); i++) {
        if(!bezierPointsDeleted.at(i)) drawPoint(bezierPoints.at(i), false, false);
    }
}

double MainWindow::slope(int x0, int x1, int y0, int y1) {
    return (double) ((y1 - y0) / (double) (x1 - x0));
}

void MainWindow::drawLine(Point p1, Point p2, bool permanent) {
    int x0 = p1.x;
    int y0 = p1.y;
    int x1 = p2.x;
    int y1 = p2.y;
    if(x1 != x0) {
        double m = slope(x0, x1, y0, y1);
        if(abs(m) > 1) {
            /* Kat nachylenia > 45 stopni - zamieniamy kolejnosc wspolrzednych w obu punktach */
            double x = x0;
            int y;
            if(y1 > y0) {
                for(y=y0; y<=y1; y++) {
                    if(permanent) drawPixel(*new Point((int) floor(x), y), QColor(255, 255, 255));
                    else drawPixel(*new Point((int) floor(x), y), QColor(254, 254, 254));

                    x += (double) 1/m;
                }
            }
            else {
                for(y=y0; y>=y1; y--) {
                    if(permanent) drawPixel(*new Point((int) floor(x), y), QColor(255, 255, 255));
                    else drawPixel(*new Point((int) floor(x), y), QColor(254, 254, 254));

                    x -= (double) 1/m;
                }
            }
        }
        else {
            int x;
            double y = y0;
            if(x1 > x0) {
                for(x=x0; x<=x1; x++) {
                    if(permanent) drawPixel(*new Point(x, (int) floor(y+0.5)), QColor(255, 255, 255));
                    else drawPixel(*new Point(x, (int) floor(y+0.5)), QColor(254, 254, 254));

                    y += m;
                }
            }
            else {
                for(x=x0; x>=x1; x--) {
                    if(permanent) drawPixel(*new Point(x, (int) floor(y+0.5)), QColor(255, 255, 255));
                    else drawPixel(*new Point(x, (int) floor(y+0.5)), QColor(254, 254, 254));

                    y -= m;
                }
            }
        }
    }
    else {
        /* Pionowy odcinek (rownanie x = a) */
        int y;
        if(y1 > y0) {
            for(y=y0; y<=y1; y++) {
                if(permanent) drawPixel(*new Point(x0, (int) floor(y+0.5)), QColor(255, 255, 255));
                else drawPixel(*new Point(x0, (int) floor(y+0.5)), QColor(254, 254, 254));
            }
        }
        else {
            for(y=y1; y<=y0; y++) {
                if(permanent) drawPixel(*new Point(x0, (int) floor(y+0.5)), QColor(255, 255, 255));
                else drawPixel(*new Point(x0, (int) floor(y+0.5)), QColor(254, 254, 254));
            }
        }
    }
}

void MainWindow::drawPoint(Point p, bool deletePoint, bool permanent) {
    if((p.x < 0)||(p.y < 0)||(p.x >= img->width()-1)||(p.y >= img->height()-1)) return;

    int x = p.x;
    int y = p.y;
    uchar *ptr = img->scanLine(y);
    uchar *ptr2 = img->scanLine(y+1);

    if(!permanent) {
        ptr[4*x] = 0;
        ptr[4*x+1] = 254;
        ptr[4*x+2] = 0;
        ptr[4*x+3] = 255;
        ptr[4*(x+1)] = 0;
        ptr[4*(x+1)+1] = 254;
        ptr[4*(x+1)+2] = 0;
        ptr[4*(x+1)+3] = 255;
        ptr2[4*x] = 0;
        ptr2[4*x+1] = 254;
        ptr2[4*x+2] = 0;
        ptr2[4*x+3] = 255;
        ptr2[4*(x+1)] = 0;
        ptr2[4*(x+1)+1] = 254;
        ptr2[4*(x+1)+2] = 0;
        ptr2[4*(x+1)+3] = 255;
    }
    else if(deletePoint) {
        ptr[4*x] = 0;
        ptr[4*x+1] = 0;
        ptr[4*x+2] = 0;
        ptr[4*x+3] = 255;
        ptr[4*(x+1)] = 0;
        ptr[4*(x+1)+1] = 0;
        ptr[4*(x+1)+2] = 0;
        ptr[4*(x+1)+3] = 255;
        ptr2[4*x] = 0;
        ptr2[4*x+1] = 0;
        ptr2[4*x+2] = 0;
        ptr2[4*x+3] = 0;
        ptr2[4*(x+1)] = 0;
        ptr2[4*(x+1)+1] = 0;
        ptr2[4*(x+1)+2] = 0;
        ptr2[4*(x+1)+3] = 255;
    }
    else {
        ptr[4*x] = 0;
        ptr[4*x+1] = 255;
        ptr[4*x+2] = 0;
        ptr[4*x+3] = 255;
        ptr[4*(x+1)] = 0;
        ptr[4*(x+1)+1] = 255;
        ptr[4*(x+1)+2] = 0;
        ptr[4*(x+1)+3] = 255;
        ptr2[4*x] = 0;
        ptr2[4*x+1] = 255;
        ptr2[4*x+2] = 0;
        ptr2[4*x+3] = 255;
        ptr2[4*(x+1)] = 0;
        ptr2[4*(x+1)+1] = 255;
        ptr2[4*(x+1)+2] = 0;
        ptr2[4*(x+1)+3] = 255;
    }
}

Point MainWindow::detectPoint(Point p) {
    float d, d_min = 1000000;
    int i, indexWithMinimalD = 0;
    int x = p.x;
    int y = p.y;
    for(i=0; i<bezierPoints.size(); i++) {
        /* Dla kazdego punktu kontrolnego obliczamy odleglosc od klikniecia */
        if(!bezierPointsDeleted.at(i)) {
            d = std::pow((x - bezierPoints.at(i).x), 2) + std::pow((y - bezierPoints.at(i).y), 2);
            if(d < d_min) {
                d_min = d;
                indexWithMinimalD = i;
            }
        }
    }
    indexOfPointToRemove = indexWithMinimalD;
    return bezierPoints.at(indexWithMinimalD);
}

void MainWindow::drawBspline(QList<Point> bezierPoints, bool permanent) {
    int i, j, x1, y1, x2, y2;
    int N = 10;
    float t = 0;
    Point P, Q, p1, p2, p3, p4;

    for(i=0; i<bezierPoints.size()-3; i++) {
        /* Pobieramy cztery punkty do narysowania konkretnej krzywej */
        p1 = bezierPoints.at(i);
        p2 = bezierPoints.at(i+1);
        p3 = bezierPoints.at(i+2);
        p4 = bezierPoints.at(i+3);

        t = 0;

        x1 = ((std::pow(-t, 3) + 3 * std::pow(t, 2) - 3 * t + 1) * p1.x) / 6.0 +
                ((3 * std::pow(t, 3) - 6 * std::pow(t, 2) + 4) * p2.x) / 6.0 +
                ((-3 * std::pow(t, 3) + 3 * std::pow(t, 2) + 3 * t + 1) * p3.x) / 6.0 +
                (std::pow(t, 3) * p4.x) / 6.0;
        y1 = ((std::pow(-t, 3) + 3 * std::pow(t, 2) - 3 * t + 1) * p1.y) / 6.0 +
                ((3 * std::pow(t, 3) - 6 * std::pow(t, 2) + 4) * p2.y) / 6.0 +
                ((-3 * std::pow(t, 3) + 3 * std::pow(t, 2) + 3 * t + 1) * p3.y) / 6.0 +
                (std::pow(t, 3) * p4.y) / 6.0;

        P.x = x1;
        P.y = y1;

        for(j=0; j<=N; j++) {
            t = (float) j / (float) N;

            x2 =((std::pow(-t, 3) + 3 * std::pow(t, 2) - 3 * t + 1) * p1.x) / 6.0 +
                    ((3 * std::pow(t, 3) - 6 * std::pow(t, 2) + 4) * p2.x) / 6.0 +
                    ((-3 * std::pow(t, 3) + 3 * std::pow(t, 2) + 3 * t + 1) * p3.x) / 6.0 +
                    (std::pow(t, 3) * p4.x) / 6.0;
            y2 = ((std::pow(-t, 3) + 3 * std::pow(t, 2) - 3 * t + 1) * p1.y) / 6.0 +
                    ((3 * std::pow(t, 3) - 6 * std::pow(t, 2) + 4) * p2.y) / 6.0 +
                    ((-3 * std::pow(t, 3) + 3 * std::pow(t, 2) + 3 * t + 1) * p3.y) / 6.0 +
                    (std::pow(t, 3) * p4.y) / 6.0;

            Q.x = x2;
            Q.y = y2;

            if(permanent) drawLine(P, Q, true);
            else drawLine(P, Q, false);

            P.x = Q.x;
            P.y = Q.y;
        }
    }


}

void MainWindow::drawPixel(Point p, QColor color) {
    int x = p.x;
    int y = p.y;

    if((x < 0)||(y < 0)||(x >= img->width())||(y >= img->height())) return;

    uchar *ptr = img->scanLine(y);

    ptr[4*x] = color.blue();
    ptr[4*x+1] = color.green();
    ptr[4*x+2] = color.red();
    ptr[4*x+3] = 255;
}

void MainWindow::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(240, 240, 240));
    p.drawImage(0, 0, *img);
    update();
}

MainWindow::~MainWindow()
{
    delete ui;
}


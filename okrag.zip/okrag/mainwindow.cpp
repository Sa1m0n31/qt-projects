#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<QPainter>
#include<QMouseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    img = new QImage(500, 500, QImage::Format_RGB32);
    centreSelected = false;
}

/* Czyszczenie ekranu */
void MainWindow::clearWindow() {
    for(int i=0; i<img->height(); i++) {
        uchar *p = img->scanLine(i);
        for(int j=0; j<img->width(); j++) {
                p[j*4] = 0;
                p[j*4+1] = 0;
                p[j*4+2] = 0;
                p[j*4+3] = 255;
        }
    }
}


void MainWindow::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(50, 50, 50));
    p.drawImage(0, 0, *img);
    update();
}

int MainWindow::calculateRadius(int x, int y) {
    return floor(sqrt((x_centre - x)*(x_centre - x) + (y_centre - y)*(y_centre - y)));
}

void MainWindow::mousePressEvent(QMouseEvent *e) {
    QPointF point = e->position();
    int x, y;

     x_centre = floor(point.x());
     y_centre = floor(point.y());
}

void MainWindow::mouseMoveEvent(QMouseEvent *e) {
    QPointF point = e->position();
    int x = floor(point.x());
    int y = floor(point.y());

    radius = calculateRadius(x, y);

    clearWindow();
    drawCircle(radius);
    update();
}

void MainWindow::drawPixel(int x, int y) {
    if((x > 0)&&(y > 0)&&(x < img->width())&&(y < img->height())) {
        uchar *ptr = img->scanLine(y);

        ptr[4*x] = 0;
        ptr[4*x + 1] = 255;
        ptr[4*x + 2] = 0;
        ptr[4*x + 3] = 0;
    }
}

void MainWindow::draw8Pixels(int x, int y) {
    drawPixel(x + x_centre, y + y_centre);
    drawPixel(-x + x_centre, y + y_centre);
    drawPixel(x + x_centre, -y + y_centre);
    drawPixel(y + x_centre, x + y_centre);
    drawPixel(-y + x_centre, x + y_centre);
    drawPixel(y + x_centre, -x + y_centre);
    drawPixel(-x + x_centre, -y + y_centre);
    drawPixel(-y + x_centre, -x + y_centre);
}

void MainWindow::drawCircle(int r) {
    int x, y, d;
    x = 0;
    y = r;
    d = 1-r;
    draw8Pixels(x, y);
    while(y>x) {
        if(d<0) {
            d = d + 2 * x + 3;
            x++;
        }
        else {
            d = d + 2 * (x - y) + 5;
            x++;
            y--;
        }
        draw8Pixels(x, y);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


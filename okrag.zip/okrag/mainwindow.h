#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QImage *img;
    int x_centre, y_centre, radius;
    bool centreSelected;

    void paintEvent(QPaintEvent *);
    void draw8Pixels(int x, int y);
    void drawPixel(int x, int y);
    void drawCircle(int r, int x_centre, int y_centre);
    void mousePressEvent(QMouseEvent *e);
    void drawCircle(int r);
    int calculateRadius(int x, int y);
    void mouseMoveEvent(QMouseEvent *e);
    void clearWindow();
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

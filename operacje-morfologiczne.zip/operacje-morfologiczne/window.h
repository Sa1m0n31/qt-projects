#ifndef WINDOW_H
#define WINDOW_H

#include <QFrame>
#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>

QT_BEGIN_NAMESPACE
namespace Ui { class Window; }
QT_END_NAMESPACE

class Window : public QMainWindow
{
    Q_OBJECT

public:
    Window(QWidget *parent = nullptr);
    ~Window();
    QImage img;
    QFrame *frame;
    QVBoxLayout *verticalLayout;
    QPushButton *dilationBtn, *erosionBtn, *openingBtn, *closingBtn;

    void paintEvent(QPaintEvent *);
    void setPixelTmp(int x, int y);
    int getPixel(int x, int y);
    void setPixelFg(int x, int y);
    void setPixelBg(int x, int y);
public slots:
    void dilation();
    void erosion();
    void opening();
    void closing();
private:
    Ui::Window *ui;
};
#endif // WINDOW_H

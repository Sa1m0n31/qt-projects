Plik ze zdjęciem potrzebny do poprawnego działania programu zlokalizowany w:
D:\operacje_morfologiczne.png
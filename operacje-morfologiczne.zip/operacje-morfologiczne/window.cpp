#include "window.h"
#include "ui_window.h"

#include <QPainter>
#include <QPalette>

Window::Window(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Window)
{
    ui->setupUi(this);

    /* Zmiana rozmiaru okna */
    resize(1920, 1080);

    /* Zaladowanie obrazu */
    img = QImage("D:\\operacje_morfologiczne.png");

    /* Pobieranie buttonow z UI */
    dilationBtn = this->ui->dilationBtn;
    erosionBtn = this->ui->erosionBtn;
    openingBtn = this->ui->openingBtn;
    closingBtn = this->ui->closingBtn;

    QObject::connect(dilationBtn, &QPushButton::released, this, &Window::dilation);
    QObject::connect(erosionBtn, &QPushButton::released, this, &Window::erosion);
    QObject::connect(openingBtn, &QPushButton::released, this, &Window::opening);
    QObject::connect(closingBtn, &QPushButton::released, this, &Window::closing);
}

void Window::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(50, 50, 50));
    p.drawImage(0, 0, img);
    update();
}

int Window::getPixel(int x, int y) {
    /* 0 - kolor tla, 1 - kolor tymczasowy, 2 - kolor pierwszoplanowy */
    uchar *ptr = img.scanLine(y);
    if(ptr[4*x] == 255) return 0;
    else if(ptr[4*x+1] == 255) return 1;
    return 2;
}

void Window::setPixelTmp(int x, int y) {
    /* Kolorujemy tymczasowo na kolor zielony */
    uchar *ptr = img.scanLine(y);
    ptr[4*x] = 0;
    ptr[4*x + 1] = 255;
    ptr[4*x + 2] = 0;
    update();
}

void Window::setPixelFg(int x, int y) {
    /* Kolorujemy na kolor czarny */
    uchar *ptr = img.scanLine(y);
    ptr[4*x] = 0;
    ptr[4*x+1] = 0;
    ptr[4*x+2] = 0;
    update();
}

void Window::setPixelBg(int x, int y) {
    uchar *ptr = img.scanLine(y);
    ptr[4*x] = 255;
    ptr[4*x+1] = 255;
    ptr[4*x+2] = 255;
    update();
}

void Window::dilation() {
    int i, j;
    int h = img.height(), w = img.width();

    /* Zaznaczamy piksele tymczasowo kolorem zielonym */
    for(i=1; i<h-1; i++) {
        for(j=0; j<w-1; j++) {
            if(!getPixel(j, i)) {
                if((getPixel(j+1, i) == 2)||(getPixel(j-1, i) == 2)||(getPixel(j, i+1) == 2)||(getPixel(j, i-1) == 2)) {
                    setPixelTmp(j, i);
                }
            }
        }
    }

    /* Kolorujemy piksele na nasz kolor pierwszoplanowy - czarny */
    for(i=1; i<h-1; i++) {
        for(j=0; j<w-1; j++) {
            if(getPixel(j, i) == 1) {
                /* Jesli kolor zielony => zmien na kolor pierwszoplanowy - czarny */
                setPixelFg(j, i);
            }
        }
    }
}

void Window::erosion() {
    int i, j;
    int h = img.height(), w = img.width();

    /* Zaznaczamy piksele tymczasowo kolorem zielonym */
    for(i=1; i<h-1; i++) {
        for(j=0; j<w-1; j++) {
            if(getPixel(j, i) == 2) {
                if((!getPixel(j+1, i))||(!getPixel(j-1, i))||(!getPixel(j, i+1))||(!getPixel(j, i-1))) {
                    setPixelTmp(j, i);
                }
            }
        }
    }

    /* Kolorujemy piksele na nasz kolor pierwszoplanowy - czarny */
    for(i=1; i<h-1; i++) {
        for(j=0; j<w-1; j++) {
            if(getPixel(j, i) == 1) {
                /* Jesli kolor zielony => zmien na kolor drugoplanowy - bialy */
                setPixelBg(j, i);
            }
        }
    }
}

void Window::opening() {
    erosion();
    dilation();
}

void Window::closing() {
    dilation();
    erosion();
}

Window::~Window()
{
    delete ui;
}


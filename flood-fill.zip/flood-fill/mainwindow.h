#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include<QMainWindow>
#include<QPushButton>
#include<QStack>

#include "point.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    /* UI elements */
    QPushButton *lineBtn, *circleBtn, *floodFillBtn, *resetBtn;
    QImage *img;

    /* Variables */
    int currentMode;
    QStack<Point> stack;
    int x0, y0, x1, y1;
    int x_s, y_s, r;

    void paintEvent(QPaintEvent *);
    void floodFill(Point p);
    bool isBackgroundColor(Point p);
    void drawPixel(Point p);
    double slope(int x0, int x1, int y0, int y1);
    void mousePressEvent(QMouseEvent *e);
    void mouseMoveEvent(QMouseEvent *e);
    void clearWindow();
    void drawLine();
    void mouseReleaseEvent(QMouseEvent *e);
    void draw8Pixels(int x, int y);
    void drawCircle();
    int calculateRadius(int x, int y);
    void resetWindow();
public slots:
    void lineActivated();
    void circleActivated();
    void floodFillActivated();
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

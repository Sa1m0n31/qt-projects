#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "point.h"

#include<QObject>
#include<QPainter>
#include<QMouseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    lineBtn = this->ui->lineBtn;
    circleBtn = this->ui->circleBtn;
    floodFillBtn = this->ui->floodFillBtn;
    resetBtn = this->ui->resetBtn;

    img = new QImage(500, height(), QImage::Format_RGB32);
    currentMode = 0;

    /* Signals */
    QObject::connect(lineBtn, &QPushButton::released, this, &MainWindow::lineActivated);
    QObject::connect(circleBtn, &QPushButton::released, this, &MainWindow::circleActivated);
    QObject::connect(floodFillBtn, &QPushButton::released, this, &MainWindow::floodFillActivated);
    QObject::connect(resetBtn, &QPushButton::released, this, &MainWindow::resetWindow);
}

/* Reset */
void MainWindow::resetWindow() {
    for(int i=0; i<img->height(); i++) {
        uchar *p = img->scanLine(i);
        for(int j=0; j<img->width(); j++) {
                p[j*4] = 0;
                p[j*4+1] = 0;
                p[j*4+2] = 0;
                p[j*4+3] = 255;
        }
    }
    currentMode = 0;
    update();
}

/* Czyszczenie ekranu */
void MainWindow::clearWindow() {
    for(int i=0; i<img->height(); i++) {
        uchar *p = img->scanLine(i);
        for(int j=0; j<img->width(); j++) {
             if(p[j*4+2] != 255) {
                p[j*4] = 0;
                p[j*4+1] = 0;
                p[j*4+2] = 0;
                p[j*4+3] = 255;
             }
        }
    }
    update();
}

void MainWindow::mousePressEvent(QMouseEvent *e) {
    QPointF position = e->position();
    int x = floor(position.x());
    int y = floor(position.y());

    if(currentMode == 0) {
        /* Rysowanie linii */
        x0 = x;
        y0 = y;
    }
    else if(currentMode == 1) {
        /* Rysowanie okregow */
        x_s = x;
        y_s = y;
    }
    else {
        /* Flood fill */
        floodFill(*new Point(x, y));
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *e) {
    QPointF position = e->position();
    int x = floor(position.x());
    int y = floor(position.y());

    if(currentMode == 0) {
        /* Rysowanie linii */
        x1 = x;
        y1 = y;

        clearWindow();
        drawLine();
    }
    else if(currentMode == 1) {
        /* Rysowanie okregow */
        r = calculateRadius(x, y);

        clearWindow();
        drawCircle();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *e) {
    /* Kolor (255, 255, 254) zmieniamy na (255, 255, 255) - zostajacy na stale */
    for(int i=0; i<img->height(); i++) {
        uchar *p = img->scanLine(i);
        for(int j=0; j<img->width(); j++) {
               if(p[j*4+2] == 254) {
                   p[j*4+2] = 255;
               }
        }
    }
    update();
}

void MainWindow::lineActivated() {
    currentMode = 0;
}

void MainWindow::circleActivated() {
    currentMode = 1;
}

void MainWindow::floodFillActivated() {
    currentMode = 2;
}

void MainWindow::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(240, 240, 240));
    p.drawImage(0, 0, *img);
    update();
}

bool MainWindow::isBackgroundColor(Point p) {
    uchar *ptr = img->scanLine(p.y);
    int x = p.x;

    return ((ptr[4*x] == 0)&&(ptr[4*x+1] == 0)&&(ptr[4*x+2] == 0));
}

void MainWindow::drawPixel(Point p) {
    int x = p.x;
    int y = p.y;

    if((x > 0)&&(y > 0)&&(x < img->width())&&(y < img->height())) {
        uchar *ptr = img->scanLine(y);

       if(ptr[4*x+2] != 255) {
           ptr[4*x] = 255;
           ptr[4*x+1] = 255;
           ptr[4*x+2] = 254;
           ptr[4*x+3] = 255;
       }
    }
}

double MainWindow::slope(int x0, int x1, int y0, int y1) {
    return (double) ((y1 - y0) / (double) (x1 - x0));
}

void MainWindow::drawLine() {
    if(x1 != x0) {
        double m = slope(x0, x1, y0, y1);
        if(abs(m) > 1) {
            int y;
            /* Kat nachylenia > 45 stopni - zamieniamy kolejnosc wspolrzednych w obu punktach */
            double x = x0;
            if(y1 > y0) {
                for(y=y0; y<=y1; y++) {
                    drawPixel(*new Point((int) floor(x), y));

                    x += (double) 1/m;
                }
            }
            else {
                for(y=y0; y>=y1; y--) {
                    drawPixel(*new Point((int) floor(x), y));

                    x -= (double) 1/m;
                }
            }
        }
        else {
            int x;
            double y = y0;
            if(x1 > x0) {
                for(x=x0; x<=x1; x++) {
                    drawPixel(*new Point(x, (int) floor(y+0.5)));

                    y += m;
                }
            }
            else {
                for(x=x0; x>=x1; x--) {
                    drawPixel(*new Point(x, (int) floor(y+0.5)));

                    y -= m;
                }
            }
        }
    }
    else {
        /* Pionowy odcinek (rownanie x = a) */
        int y;
        if(y1 > y0) {
            for(y=y0; y<=y1; y++) {
                drawPixel(*new Point(x0, (int) floor(y+0.5)));
            }
        }
        else {
            for(y=y1; y<=y0; y++) {
                drawPixel(*new Point(x0, (int) floor(y+0.5)));
            }
        }
    }
}

int MainWindow::calculateRadius(int x, int y) {
    return floor(sqrt((x_s - x)*(x_s - x) + (y_s - y)*(y_s - y)));
}

void MainWindow::draw8Pixels(int x, int y) {
    drawPixel(*new Point(x + x_s, y + y_s));
    drawPixel(*new Point(-x + x_s, y + y_s));
    drawPixel(*new Point(x + x_s, -y + y_s));
    drawPixel(*new Point(y + x_s, x + y_s));
    drawPixel(*new Point(-y + x_s, x + y_s));
    drawPixel(*new Point(y + x_s, -x + y_s));
    drawPixel(*new Point(-x + x_s, -y + y_s));
    drawPixel(*new Point(-y + x_s, -x + y_s));
}

void MainWindow::drawCircle() {
    int x, y, d;
    x = 0;
    y = r;
    d = 1-r;
    draw8Pixels(x, y);
    while(y>x) {
        if(d<0) {
            d = d + 2 * x + 3;
            x++;
        }
        else {
            d = d + 2 * (x - y) + 5;
            x++;
            y--;
        }
        draw8Pixels(x, y);
    }
}

void MainWindow::floodFill(Point p) {
    int x, y;
    stack.push(p);
    while(!stack.isEmpty()) {
        p = stack.pop();
        if(isBackgroundColor(p)) {
             drawPixel(p);

             x = p.x;
             y = p.y;

             if((x > 1)&&(y > 1)&&(x < img->width()-1)&&(y < img->height()-1)) {
                 stack.push(*new Point(x+1, y));
                 stack.push(*new Point(x-1, y));
                 stack.push(*new Point(x, y+1));
                 stack.push(*new Point(x, y-1));
             }
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<cmath>
#include<cstdlib>

#include "point.h"
#include<QPaintEvent>
#include<QPainter>
#include<QList>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    verticesSlider = this->ui->verticesSlider;
    verticesLabel = this->ui->verticesLabel;
    img = new QImage(700, height(), QImage::Format_RGB32);

    verticesSlider->setRange(4, 100);

    /* Initial */
    numberOfVertices = 10;
    centre = new Point(100, 100);
    a = 100;
    b = 100;

    /* Signals and slots */
    QObject::connect(verticesSlider, SIGNAL(valueChanged(int)), SLOT(numberOfVerticesChanged(int)));
}

/* Klikniecie */
void MainWindow::mousePressEvent(QMouseEvent *e) {
    QPointF position = e->position();
    int x = floor(position.x());
    int y = floor(position.y());
    centre->x = x;
    centre->y = y;
}

/* Przesuniecie myszy */
void MainWindow::mouseMoveEvent(QMouseEvent *e) {
    QPointF position = e->position();
    int x = floor(position.x());
    int y = floor(position.y());

    a = std::max(x, centre->x) - std::min(x, centre->x);
    b = std::max(y, centre->y) - std::min(y, centre->y);

    clearWindow();
    update();
    vertices.clear();
    drawEllipse(*centre, a, b);
}

/* Upuszczenie myszy */
void MainWindow::mouseReleaseEvent(QMouseEvent *e) {

}

/* Czyszczenie ekranu */
void MainWindow::clearWindow() {
    for(int i=0; i<img->height(); i++) {
        uchar *p = img->scanLine(i);
        for(int j=0; j<img->width(); j++) {
                p[j*4] = 0;
                p[j*4+1] = 0;
                p[j*4+2] = 0;
                p[j*4+3] = 255;
        }
    }
}

void MainWindow::numberOfVerticesChanged(int v) {
    numberOfVertices = v;
    verticesLabel->setText("Liczba wierzchołków: " + QString::number(v));
    clearWindow();
    vertices.clear();
    update();
    drawEllipse(*centre, a, b);
    update();
}

void MainWindow::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(240, 240, 240));
    p.drawImage(0, 0, *img);
    update();
}

double MainWindow::slope(int x0, int x1, int y0, int y1) {
    return (double) ((y1 - y0) / (double) (x1 - x0));
}

void MainWindow::drawPixel(int x, int y) {
    if((x > 0)&&(y > 0)&&(x < img->width())&&(y < img->height())) {
        uchar *ptr = img->scanLine(y);

        ptr[4*x] = 255;
        ptr[4*x + 1] = 255;
        ptr[4*x + 2] = 255;
        ptr[4*x + 3] = 255;
    }
}

void MainWindow::drawLine(int x0, int y0, int x1, int y1) {
    if(x1 != x0) {
        int y;
        double m = slope(x0, x1, y0, y1);
        if(abs(m) > 1) {
            /* Kat nachylenia > 45 stopni - zamieniamy kolejnosc wspolrzednych w obu punktach */
            double x = x0;
            if(y1 > y0) {
                for(y=y0; y<=y1; y++) {
                    drawPixel((int) floor(x), y);

                    x += (double) 1/m;
                }
            }
            else {
                for(y=y0; y>=y1; y--) {
                    drawPixel((int) floor(x), y);

                    x -= (double) 1/m;
                }
            }
        }
        else {
            int x;
            double y = y0;
            if(x1 > x0) {
                for(x=x0; x<=x1; x++) {
                       drawPixel(x, (int) floor(y+0.5));

                    y += m;
                }
            }
            else {
                for(x=x0; x>=x1; x--) {
                        drawPixel(x, (int) floor(y+0.5));

                    y -= m;
                }
            }
        }
    }
    else {
        int y;
        /* Pionowy odcinek (rownanie x = a) */
        if(y1 > y0) {
            for(y=y0; y<=y1; y++) {
                   drawPixel(x0, (int) floor(y+0.5));
            }
        }
        else {
            for(y=y1; y<=y0; y++) {
                drawPixel(x0, (int) floor(y+0.5));
            }
        }
    }

}

int MainWindow::calculateDistance(Point a, Point b) {
    return floor(sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y)));
}

void MainWindow::drawEllipse(Point centre, int a, int b) {
    float difference = M_PI / (float) (numberOfVertices / 2);
    float alpha = 0;
    int i, x, y;
    for(i=0; i<numberOfVertices; i++) {
        x = floor(a * cos(alpha)) + centre.x;
        y = floor(b * sin(alpha)) + centre.y;

        vertices.append(*new Point(x, y));

        alpha += difference;
    }

    for(i=0; i<vertices.size()-1; i++) {
         drawLine(vertices.at(i).x, vertices.at(i).y, vertices.at(i+1).x, vertices.at(i+1).y);
    }
    drawLine(vertices.at(i).x, vertices.at(i).y, vertices.at(0).x, vertices.at(0).y);
}

MainWindow::~MainWindow()
{
    delete ui;
}


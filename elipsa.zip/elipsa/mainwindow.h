#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QList>
#include<QSlider>
#include<QLabel>
#include "point.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QImage *img;
    QSlider *verticesSlider;
    QLabel *verticesLabel;
    int numberOfVertices;
    QList<Point> vertices;

    Point *centre;
    int a, b;

    void paintEvent(QPaintEvent *);
    void drawEllipse(Point centre, int a, int b);
    int calculateDistance(Point a, Point b);
    void drawPixel(int x, int y);
    void drawLine(int x0, int y0, int x1, int y1);
    double slope(int x0, int x1, int y0, int y1);
    void clearWindow();
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *e);
    void mouseReleaseEvent(QMouseEvent *e);
public slots:
    void numberOfVerticesChanged(int v);
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "matrix.h"
#include "color.h"

#include<QMainWindow>
#include<QSlider>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QImage *img, *transformedImg, *backgroundImg, *transformedBackground;
    QSlider *transformXSlider, *transformYSlider, *scaleXSlider, *scaleYSlider, *rotateSlider, *shearingXSlider, *shearingYSlider;
    void paintEvent(QPaintEvent *event);

    int transformXValue, transformYValue, rotateValue, shearingXValue, shearingYValue;
    float scaleXValue, scaleYValue;

    double tmpResult[3][1];

    Color getPixelColor(int x, int y);
    void drawPixel(int x, int y, Color color);
    void allOperations();
    void multiplyMatrices(double matrixA[][3], double matrixB[][1]);
public slots:
    void handleTransformX(int v);
    void handleTransformY(int v);
    void handleScaleX(int v);
    void handleScaleY(int v);
    void handleRotate(int v);
    void handleShearingX(int v);
    void handleShearingY(int v);
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

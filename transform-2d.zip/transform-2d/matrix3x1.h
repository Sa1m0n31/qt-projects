#ifndef MATRIX3X1_H
#define MATRIX3X1_H


class Matrix3x1
{
public:
    Matrix3x1();
};

#endif // MATRIX3X1_H

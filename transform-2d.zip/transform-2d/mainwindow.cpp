#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<cmath>

#include "mainwindow.h"
#include "matrix.h"
#include "color.h"

#include<QVector>
#include<QPainter>
#include<QImage>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /* Elementy UI */
    backgroundImg = new QImage(500, height(), QImage::Format_RGB32);
    img = new QImage("D:\\player.png");
    transformedBackground = new QImage(500, height(), QImage::Format_RGB32);
    transformedImg = new QImage(500, height(), QImage::Format_RGB32);

    transformXSlider = this->ui->transformX;
    transformYSlider = this->ui->transformY;
    scaleXSlider = this->ui->scaleX;
    scaleYSlider = this->ui->scaleY;
    rotateSlider = this->ui->rotate;
    shearingXSlider = this->ui->shearingX;
    shearingYSlider = this->ui->shearingY;

    transformXSlider->setRange(0, 500);
    transformYSlider->setRange(0, height());
    scaleXSlider->setRange(0, 200);
    scaleYSlider->setRange(0, 200);
    rotateSlider->setRange(0, 360);
    shearingXSlider->setRange(-100, 100);
    shearingYSlider->setRange(-100, 100);

    transformXSlider->setValue(floor(250 - (img->width() / 2)));
    transformYSlider->setValue(floor(height() / 2 - (img->height() / 2)));
    scaleXSlider->setValue(100);
    scaleYSlider->setValue(100);

    transformXValue = floor(250 - (img->width() / 2));
    transformYValue = floor(height() / 2 - (img->height() / 2));
    scaleXValue = 1;
    scaleYValue = 1;
    rotateValue = 0;
    shearingXValue = 0;
    shearingYValue = 0;

    QObject::connect(transformXSlider, SIGNAL(valueChanged(int)), SLOT(handleTransformX(int)));
    QObject::connect(transformYSlider, SIGNAL(valueChanged(int)), SLOT(handleTransformY(int)));
    QObject::connect(scaleXSlider, SIGNAL(valueChanged(int)), SLOT(handleScaleX(int)));
    QObject::connect(scaleYSlider, SIGNAL(valueChanged(int)), SLOT(handleScaleY(int)));
    QObject::connect(rotateSlider, SIGNAL(valueChanged(int)), SLOT(handleRotate(int)));
    QObject::connect(shearingXSlider, SIGNAL(valueChanged(int)), SLOT(handleShearingX(int)));
    QObject::connect(shearingYSlider, SIGNAL(valueChanged(int)), SLOT(handleShearingY(int)));

    allOperations();
}

void MainWindow::handleTransformX(int v) {
    transformXValue = v;
    allOperations();
}

void MainWindow::handleTransformY(int v) {
    transformYValue = v;
    allOperations();
}

void MainWindow::handleScaleX(int v) {
    scaleXValue = (float) v / (float) 100;
    allOperations();
}

void MainWindow::handleScaleY(int v) {
    scaleYValue = (float) v / (float) 100;
    allOperations();
}

void MainWindow::handleRotate(int v) {
    rotateValue = v;
    allOperations();
}

void MainWindow::handleShearingX(int v) {
    shearingXValue = (float) v / (float) 10;
    allOperations();
}

void MainWindow::handleShearingY(int v) {
    shearingYValue = (float) v / (float) 10;
    allOperations();
}

void MainWindow::allOperations() {
    double allOperationsMatrix[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};
    double coordinatesMatrix[3][1] = {{0}, {0}, {0}};
    int i, j, x, y;

    float a = (float) 1 / (float) scaleXValue;
    float b = (float) 1 / (float) scaleYValue;
    float c = shearingXValue;
    float d = shearingYValue;
    int e = transformXValue;
    int f = transformYValue;
    float cosAlpha = std::cos((double) rotateValue * M_PI / (double) 180);
    float sinAlpha = std::sin((double) rotateValue * M_PI / (double) 180);

    /* Macierz wszystkich transformacji to wynik mnozenia macierzy: S_x * S_y * R * Sh_x * Sh_y * T_x * T_y */
    allOperationsMatrix[0][0] = a * cosAlpha * (c*d + 1) - a*d*sinAlpha;
    allOperationsMatrix[0][1] = a * sinAlpha - a * c * cosAlpha;
    allOperationsMatrix[0][2] = -e * (a * cosAlpha) * (c*d+1) - f *(a * sinAlpha - a*c * cosAlpha);
    allOperationsMatrix[1][0] = -b * sinAlpha *(c*d+1) - b*d*cosAlpha;
    allOperationsMatrix[1][1] = b * cosAlpha + b * c * sinAlpha;
    allOperationsMatrix[1][2] = -e * (-b * sinAlpha * (c*d+1) - b*d*cosAlpha) - f *(b * cosAlpha + b*c*sinAlpha);
    allOperationsMatrix[2][0] = 0;
    allOperationsMatrix[2][1] = 0;
    allOperationsMatrix[2][2] = 1;

    coordinatesMatrix[0][0] = 0;
    coordinatesMatrix[1][0] = 0;
    coordinatesMatrix[2][0] = 1;

    Color color;

    /* Przechodzimy przez kazdy piksel nowego obrazu i sprawdzamy w ktory piksel starego obrazu trafimy */
    for(i=0; i<backgroundImg->width(); i++) {
        for(j=0; j<backgroundImg->height(); j++) {

            coordinatesMatrix[0][0] = i;
            coordinatesMatrix[1][0] = j;

            multiplyMatrices(allOperationsMatrix, coordinatesMatrix);

            x = floor(tmpResult[0][0]);
            y = floor(tmpResult[1][0]);

            color = getPixelColor(x, y);

            drawPixel(i, j, color);
        }
    }

    update();
}

Color MainWindow::getPixelColor(int x, int y) {
    Color color(240, 240, 240);
    if((x < 0)||(y < 0)||(x >= img->width())||(y >= img->height())) return color;

    uchar *ptr;
    ptr = img->scanLine(y);

    color.b = ptr[4*x];
    color.g = ptr[4*x + 1];
    color.r = ptr[4*x + 2];

    return color;
}

void MainWindow::drawPixel(int x, int y, Color color) {
    if((x < 0)||(y < 0)||(x >= backgroundImg->width())||(y >= backgroundImg->height())) return;

    uchar *ptr = backgroundImg->scanLine(y);

    ptr[4*x] = color.b;
    ptr[4*x + 1] = color.g;
    ptr[4*x + 2] = color.r;
    ptr[4*x + 3] = 255;
}

void MainWindow::multiplyMatrices(double matrixA[][3], double matrixB[][1]) {
    int i, j, k;
    double value;

    for(i=0; i<3; i++) { // Wiersze pierwszej macierzy
        for(j=0; j<1; j++) { // Kolumny drugiej macierzy
            value = 0;
            for(k=0; k<3; k++) { // Wiersze drugiej macierzy
                value += matrixA[i][k] * matrixB[k][j];
            }
            tmpResult[i][j] = value;
        }
    }
}

void MainWindow::paintEvent(QPaintEvent *event) {
    QPainter p(this);
    p.fillRect(0, 0, 500, height(), QColor(50, 50, 50));
    p.drawImage(0, 0, *backgroundImg);
}

MainWindow::~MainWindow()
{
    delete ui;
}


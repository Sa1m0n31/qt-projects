#include "matrix3x1.h"

Matrix3x1::Matrix3x1()
{

}

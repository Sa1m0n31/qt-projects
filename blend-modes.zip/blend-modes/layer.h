#ifndef LAYER_H
#define LAYER_H

#include <QImage>

class Layer
{
public:
    Layer();
    Layer(QString name, QImage img, int mode, float alpha);
    QImage img;
    QString name;
    int mode;
    float alpha;
    void setAlpha(float alpha);
    void setMode(int mode);
};

#endif // LAYER_H

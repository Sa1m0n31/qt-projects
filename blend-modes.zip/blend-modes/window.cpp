#include "window.h"
#include "ui_window.h"

#include <QPaintEvent>
#include <QPainter>
#include <QSignalMapper>

#include <QComboBox>
#include <QRadioButton>
#include <QSlider>
#include <QVBoxLayout>

Window::Window(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Window)
{
    ui->setupUi(this);

    /* Resize window */
    resize(1900, 1000);

    img1 = QImage("D:\\img1.jpg");
    img2 = QImage("D:\\img2.jpg");
    img3 = QImage("D:\\img3.jpg");

    mainImage = img1;

    /* Inicjalizacja obiektow klasy Layer */
    layer1 = new Layer("Pierwsza warstwa", img1, 0, 1);
    layer2 = new Layer("Druga wartstwa", img2, 0, 1);
    layer3 = new Layer("Trzecia warstwa", img3, 0, 1);
    layers = { *layer1, *layer2, *layer3 };

    /* Pobierz elementy UI */
    blendingModesComboBox1 = this->ui->blendingModesComboBox1;
    blendingModesComboBox2 = this->ui->blendingModesComboBox2;
    blendingModesComboBox3 = this->ui->blendingModesComboBox3;

    QSlider *alphaSlider1 = this->ui->alphaSlider1;
    QSlider *alphaSlider2 = this->ui->alphaSlider2;
    QSlider *alphaSlider3 = this->ui->alphaSlider3;

    alphaSlider1->setRange(0, 100);
    alphaSlider2->setRange(0, 100);
    alphaSlider3->setRange(0, 100);
    alphaSlider1->setValue(100);
    alphaSlider2->setValue(100);
    alphaSlider3->setValue(100);

    /* Connect */
    QObject::connect(alphaSlider1, SIGNAL(valueChanged(int)), SLOT(changeAlphaSlider1(int)));
    QObject::connect(alphaSlider2, SIGNAL(valueChanged(int)), SLOT(changeAlphaSlider2(int)));
    QObject::connect(alphaSlider3, SIGNAL(valueChanged(int)), SLOT(changeAlphaSlider3(int)));

    QObject::connect(blendingModesComboBox1, SIGNAL(currentIndexChanged(int)), SLOT(changeBlendingMode1(int)));
    QObject::connect(blendingModesComboBox2, SIGNAL(currentIndexChanged(int)), SLOT(changeBlendingMode2(int)));
    QObject::connect(blendingModesComboBox3, SIGNAL(currentIndexChanged(int)), SLOT(changeBlendingMode3(int)));
}

void Window::blend(QImage background, QImage foreground, float alpha, int mode, QImage *result) {
    int i, j;
    uchar *backgroundLine, *foregroundLine, *resultLine;
    switch(mode) {
        case 0: /* Normal mode */
            for(i=0; i<853; i++) {
                backgroundLine = background.scanLine(i);
                foregroundLine = foreground.scanLine(i);
                resultLine = result->scanLine(i);
                for(j=0; j<1278; j++) {
                    resultLine[4*j] = alpha * foregroundLine[4*j] + (1-alpha) * backgroundLine[4*j];
                    resultLine[4*j+1] = alpha * foregroundLine[4*j+1] + (1-alpha) * backgroundLine[4*j+1];
                    resultLine[4*j+2] = alpha * foregroundLine[4*j+2] + (1-alpha) * backgroundLine[4*j+2];
                }
            }
           break;
        case 1: /* Darken mode */
            for(i=0; i<853; i++) {
                backgroundLine = background.scanLine(i);
                foregroundLine = foreground.scanLine(i);
                resultLine = result->scanLine(i);
                for(j=0; j<1278; j++) {
                    resultLine[4*j] = alpha * darkenMode(backgroundLine[4*j], foregroundLine[4*j]) + (1-alpha) * backgroundLine[4*j];
                    resultLine[4*j+1] = alpha * darkenMode(backgroundLine[4*j+1], foregroundLine[4*j+1]) + (1-alpha) * backgroundLine[4*j+1];
                    resultLine[4*j+2] = alpha * darkenMode(backgroundLine[4*j+2], foregroundLine[4*j+2]) + (1-alpha) * backgroundLine[4*j+2];
                }
            }
            break;
        case 2: /* Lighten mode */
            for(i=0; i<853; i++) {
                backgroundLine = background.scanLine(i);
                foregroundLine = foreground.scanLine(i);
                resultLine = result->scanLine(i);
                for(j=0; j<1278; j++) {
                    resultLine[4*j] = alpha * lightenMode(backgroundLine[4*j], foregroundLine[4*j]) + (1-alpha) * backgroundLine[4*j];
                    resultLine[4*j+1] = alpha * lightenMode(backgroundLine[4*j+1], foregroundLine[4*j+1]) + (1-alpha) * backgroundLine[4*j+1];
                    resultLine[4*j+2] = alpha * lightenMode(backgroundLine[4*j+2], foregroundLine[4*j+2]) + (1-alpha) * backgroundLine[4*j+2];
                }
            }
            break;
        case 3: /* Multiply mode */
            for(i=0; i<853; i++) {
                backgroundLine = background.scanLine(i);
                foregroundLine = foreground.scanLine(i);
                resultLine = result->scanLine(i);
                for(j=0; j<1278; j++) {
                    resultLine[4*j] = alpha * multiplyMode(backgroundLine[4*j], foregroundLine[4*j]) + (1-alpha) * backgroundLine[4*j];
                    resultLine[4*j+1] = alpha * multiplyMode(backgroundLine[4*j+1], foregroundLine[4*j+1]) + (1-alpha) * backgroundLine[4*j+1];
                    resultLine[4*j+2] = alpha * multiplyMode(backgroundLine[4*j+2], foregroundLine[4*j+2]) + (1-alpha) * backgroundLine[4*j+2];
                }
            }
            break;
        case 4: /* Additive mode */
            for(i=0; i<853; i++) {
                backgroundLine = background.scanLine(i);
                foregroundLine = foreground.scanLine(i);
                resultLine = result->scanLine(i);
                for(j=0; j<1278; j++) {
                    resultLine[4*j] = alpha * additiveMode(backgroundLine[4*j], foregroundLine[4*j]) + (1-alpha) * backgroundLine[4*j];
                    resultLine[4*j+1] = alpha * additiveMode(backgroundLine[4*j+1], foregroundLine[4*j+1]) + (1-alpha) * backgroundLine[4*j+1];
                    resultLine[4*j+2] = alpha * additiveMode(backgroundLine[4*j+2], foregroundLine[4*j+2]) + (1-alpha) * backgroundLine[4*j+2];
                }
            }
            break;
        default:
            break;
    }
}

int Window::darkenMode(int backgroundPixel, int foregroundPixel) {
    if(backgroundPixel > foregroundPixel) backgroundPixel = foregroundPixel;
    return backgroundPixel;
}

int Window::lightenMode(int backgroundPixel, int foregroundPixel) {
    if(backgroundPixel < foregroundPixel) backgroundPixel = foregroundPixel;
    return backgroundPixel;
}

int Window::multiplyMode(int backgroundPixel, int foregroundPixel) {
    return backgroundPixel * foregroundPixel >> 8;
}

int Window::additiveMode(int backgroundPixel, int foregroundPixel) {
    int sum;
    sum = backgroundPixel + foregroundPixel;
    if(sum > 255) return sum;
    else return 255;
}

void Window::changeBlendingMode1(int mode) {
    layers[0].setMode(mode);
    printLayers();
    update();
}

void Window::changeBlendingMode2(int mode) {
    layers[1].setMode(mode);
    printLayers();
    update();
}

void Window::changeBlendingMode3(int mode) {
    layers[2].setMode(mode);
    printLayers();
    update();
}

void Window::changeAlphaSlider1(int value) {
    layers[0].setAlpha((float) value / 100);
    printLayers();
    update();
}

void Window::changeAlphaSlider2(int value) {
    layers[1].setAlpha((float) value / 100);
    printLayers();
    update();
}

void Window::changeAlphaSlider3(int value) {
    layers[2].setAlpha((float) value / 100);
    printLayers();
    update();
}

void Window::printLayers() {
    int i;
    for(i=2; i>=0; i--) {
        blend(mainImage, layers[i].img, layers[i].alpha, layers[i].mode, &mainImage);
    }
}

void Window::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(50, 50, 50));
    p.drawImage(0, 0, mainImage);
    update();
}

Window::~Window()
{
    delete ui;
}

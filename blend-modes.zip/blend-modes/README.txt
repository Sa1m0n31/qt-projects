Ścieżki zdjęć, które ładujemy w czasie działania programu:
D:\img1.jpg
D:\img2.jpg
D:\img3.jpg
#include "layer.h"

Layer::Layer()
{

}

Layer::Layer(QString name, QImage img, int mode, float alpha) {
    this->name = name;
    this->img = img;
    this->mode = mode;
    this->alpha = alpha;
}

void Layer::setAlpha(float alpha) {
    this->alpha = alpha;
}

void Layer::setMode(int mode) {
    this->mode = mode;
}

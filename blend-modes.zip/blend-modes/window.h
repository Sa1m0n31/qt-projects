#ifndef WINDOW_H
#define WINDOW_H

#include "layer.h"

#include <QMainWindow>
#include <QImage>
#include <vector>
#include <QComboBox>

QT_BEGIN_NAMESPACE
namespace Ui { class Window; }
QT_END_NAMESPACE

class Window : public QMainWindow
{
    Q_OBJECT

public:
    Window(QWidget *parent = nullptr);
    ~Window();
    QImage img1, img2, img3;
    QImage mainImage;
    QComboBox *blendingModesComboBox1;
    QComboBox *blendingModesComboBox2;
    QComboBox *blendingModesComboBox3;
    Layer *layer1, *layer2, *layer3;
    QList<Layer> layers;

    void paintEvent(QPaintEvent *);

    void blend(QImage background, QImage foreground, float alpha, int mode, QImage *result);

    int darkenMode(int backgroundPixel, int foregroundPixel);
    void printLayers();
    int lightenMode(int backgroundPixel, int foregroundPixel);
    int multiplyMode(int backgroundPixel, int foregroundPixel);
    int additiveMode(int backgroundPixel, int foregroundPixel);

private slots:
    void changeAlphaSlider1(int value);
    void changeAlphaSlider2(int value);
    void changeAlphaSlider3(int value);
    void changeBlendingMode1(int mode);
    void changeBlendingMode2(int mode);
    void changeBlendingMode3(int mode);
private:
    Ui::Window *ui;
};
#endif // WINDOW_H

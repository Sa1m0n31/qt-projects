#include "image.h"

Image::Image(QWidget *parent) : QWidget(parent)
{
    QImage(":zmiana-barw/photo.jpg");

}

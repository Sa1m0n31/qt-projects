#include "window.h"
#include "ui_window.h"
#include "hsv.h"

#include <QGraphicsView>
#include <QPushButton>
#include <QHBoxLayout>
#include <QImage>
#include <QLabel>
#include <QPainter>
#include <qimage.h>
#include <qslider.h>

Window::Window(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Window)
{
    ui->setupUi(this);

    img = QImage(255, 255, QImage::Format_RGB32);

    QSlider *redSlider = this->ui->redSlider;
    QSlider *greenSlider = this->ui->greenSlider;
    QSlider *blueSlider = this->ui->blueSlider;

    QSlider *hueSlider = this->ui->hueSlider;
    QSlider *saturationSlider = this->ui->saturationSlider;
    QSlider *valueSlider = this->ui->valueSlider;

    QPushButton *closeBtn = this->ui->closeBtn;

    redSlider->setRange(0, 255);
    greenSlider->setRange(0, 255);
    blueSlider->setRange(0, 255);

    hueSlider->setRange(0, 255);
    saturationSlider->setRange(0, 255);
    valueSlider->setRange(0, 255);

    /* RGB connect */
    QObject::connect(redSlider, SIGNAL(valueChanged(int)), SLOT(paintRectWithRed(int)));
    QObject::connect(greenSlider, SIGNAL(valueChanged(int)), SLOT(paintRectWithGreen(int)));
    QObject::connect(blueSlider, SIGNAL(valueChanged(int)), SLOT(paintRectWithBlue(int)));

    /* HSV connect */
    QObject::connect(hueSlider, SIGNAL(valueChanged(int)), SLOT(paintRectWithHue(int)));
    QObject::connect(saturationSlider, SIGNAL(valueChanged(int)), SLOT(paintRectWithSaturation(int)));
    QObject::connect(valueSlider, SIGNAL(valueChanged(int)), SLOT(paintRectWithValue(int)));

    /* Close button */
    QObject::connect(closeBtn, SIGNAL(clicked()), this, SLOT(exitWindow()));
}

void Window::exitWindow() {
    Window::close();
}

void Window::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.fillRect(width() - 255, 150, 255, 255, QColor(0, 0, 0));
    p.drawImage(width()-255, 150, img);
    update();
}

void Window::printSquare(int color, int value) {
    int i, j;
    uchar *ptr;
            if(color == 0) {
                /* Zmieniamy kolor czerwony */
                for(i=0; i<255; i++) {
                    ptr = img.scanLine(i);
                    for(j=0; j<255; j++) {
                        ptr[4*j] = j;
                        ptr[4*j + 1] = i;
                        ptr[4*j + 2] = value;
                    }
                }
            }
            else if(color == 1) {
                /* Zmieniamy kolor zielony */
                for(i=0; i<255; i++) {
                    ptr = img.scanLine(i);
                    for(j=0; j<255; j++) {
                        ptr[4*j] = i;
                        ptr[4*j + 1] = value;
                        ptr[4*j + 2] = j;
                    }
                }
            }
            else {
                /* Zmieniamy kolor niebieski */
                for(i=0; i<255; i++) {
                    ptr = img.scanLine(i);
                    for(j=0; j<255; j++) {
                        ptr[4*j] = value;
                        ptr[4*j + 1] = i;
                        ptr[4*j + 2] = j;
                    }
                }
            }
    update();
}

void Window::printSquareWithHSV(int part, int value) {
    int i, j;
    uchar *ptr;
    HSV hsv;
    RGB rgb;
            if(part == 0) {
                /* Zmieniamy barwe */
                for(i=0; i<255; i++) {
                    ptr = img.scanLine(i);
                    for(j=0; j<255; j++) {
                        hsv.h = value;
                        hsv.s = j;
                        hsv.v = i;

                        rgb = convertHSVToRGB(hsv);

                        ptr[4*j] = rgb.b;
                        ptr[4*j + 1] = rgb.g;
                        ptr[4*j + 2] = rgb.r;
                    }
                }
            }
            else if(part == 1) {
                /* Zmieniamy saturacje */
                for(i=0; i<255; i++) {
                    ptr = img.scanLine(i);
                    for(j=0; j<255; j++) {
                        hsv.h = i;
                        hsv.s = value;
                        hsv.v = j;

                        rgb = convertHSVToRGB(hsv);

                        ptr[4*j] = rgb.b;
                        ptr[4*j + 1] = rgb.g;
                        ptr[4*j + 2] = rgb.r;
                    }
                }
            }
            else {
                /* Zmieniamy wartosc */
                for(i=0; i<255; i++) {
                    ptr = img.scanLine(i);
                    for(j=0; j<255; j++) {
                        hsv.h = i;
                        hsv.s = j;
                        hsv.v = value;

                        rgb = convertHSVToRGB(hsv);

                        ptr[4*j] = rgb.b;
                        ptr[4*j + 1] = rgb.g;
                        ptr[4*j + 2] = rgb.r;
                    }
                }
            }
    update();
}

void Window::paintRectWithRed(int n) {
    printSquare(0, n);
}

void Window::paintRectWithBlue(int n) {
    printSquare(2, n);
}

void Window::paintRectWithGreen(int n) {
    printSquare(1, n);
}

void Window::paintRectWithHue(int n) {
    printSquareWithHSV(0, n);
}

void Window::paintRectWithSaturation(int n) {
    printSquareWithHSV(1, n);
}

void Window::paintRectWithValue(int n) {
    printSquareWithHSV(2, n);
}

RGB Window::convertHSVToRGB(HSV hsv) {
   RGB rgb;
        unsigned char region, remainder, p, q, t;

        if (hsv.s == 0)
        {
            rgb.r = hsv.v;
            rgb.g = hsv.v;
            rgb.b = hsv.v;
            return rgb;
        }

        region = hsv.h / 43;
        remainder = (hsv.h - (region * 43)) * 6;

        p = (hsv.v * (255 - hsv.s)) >> 8;
        q = (hsv.v * (255 - ((hsv.s * remainder) >> 8))) >> 8;
        t = (hsv.v * (255 - ((hsv.s * (255 - remainder)) >> 8))) >> 8;

        switch (region)
        {
            case 0:
                rgb.r = hsv.v; rgb.g = t; rgb.b = p;
                break;
            case 1:
                rgb.r = q; rgb.g = hsv.v; rgb.b = p;
                break;
            case 2:
                rgb.r = p; rgb.g = hsv.v; rgb.b = t;
                break;
            case 3:
                rgb.r = p; rgb.g = q; rgb.b = hsv.v;
                break;
            case 4:
                rgb.r = t; rgb.g = p; rgb.b = hsv.v;
                break;
            default:
                rgb.r = hsv.v; rgb.g = p; rgb.b = q;
                break;
        }

        return rgb;
}

Window::~Window()
{
    delete ui;
}


#include "rgb.h"

RGB::RGB() {

}

RGB::RGB(int r, int g, int b)
{
    this->r = r;
    this->g = g;
    this->b = b;
}

#ifndef WINDOW_H
#define WINDOW_H

#include "hsv.h"
#include "rgb.h"

#include <QLineEdit>
#include <QTextEdit>
#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Window; }
QT_END_NAMESPACE

class Window : public QWidget
{
    Q_OBJECT

public:
    Window(QWidget *parent = nullptr);
    ~Window();


    QImage img;
    void paintEvent(QPaintEvent *);
    void printSquare(int color, int value);
    RGB convertHSVToRGB(HSV in);
    void printSquareWithHSV(int part, int value);

private slots:
    void exitWindow();
    void paintRectWithRed(int n);
    void paintRectWithGreen(int n);
    void paintRectWithBlue(int n);
    void paintRectWithHue(int n);
    void paintRectWithSaturation(int n);
    void paintRectWithValue(int n);

private:
    QLineEdit *nameLine;
    QTextEdit *addressText;
    Ui::Window *ui;
};
#endif // WINDOW_H

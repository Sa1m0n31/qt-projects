#ifndef HSV_H
#define HSV_H


class HSV
{
public:
    int h;
    int s;
    int v;

    HSV();
    HSV(int h, int s, int v);
};

#endif // HSV_H

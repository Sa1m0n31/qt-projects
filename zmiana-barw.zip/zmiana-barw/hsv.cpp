#include "hsv.h"

HSV::HSV()
{

}

HSV::HSV(int h, int s, int v) {
    this->h = h;
    this->s = s;
    this->v = v;
}

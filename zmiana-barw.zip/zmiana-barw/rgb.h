#ifndef RGB_H
#define RGB_H


class RGB
{
public:
    RGB();
    RGB(int r, int g, int b);
    int r;
    int g;
    int b;
};

#endif // RGB_H

#ifndef EKRAN_H
#define EKRAN_H

#include <QWidget>

class Ekran : public QWidget
{
    Q_OBJECT
public:
    QImage img;
    int x0, y0, x1, y1, x, y;

    explicit Ekran(QWidget *parent = nullptr);
    void wstawPixel();
    void mouseReleaseEvent(QMouseEvent *event);
    void wstawPixel(int x, int y, int r, int g, int b);
    void mouseMoveEvent(QMouseEvent *e);
    void clearWindow();
    void rysuj(bool permanent);
protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *event);

signals:

};

#endif // EKRAN_H

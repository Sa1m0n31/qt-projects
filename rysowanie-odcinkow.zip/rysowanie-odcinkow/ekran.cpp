#include "ekran.h"
#include <QImage>
#include <QMouseEvent>
#include <QPainter>
#include <qimage.h>

Ekran::Ekran(QWidget *parent) : QWidget(parent)
{
    /* Ustawiamy nasze plotno do rysowania */
    img = QImage(width(), height(), QImage::Format_RGB32);
}

void Ekran::wstawPixel(int x, int y, int r, int g, int b) {
    /* Sprawdzamy czy znajdujemy sie wewnatrz okna */
    if(x > img.width() || x < 0 || y > img.height() || y < 0) {
        return;
    }

    /* Pobieramy wskaznik do pierwszego piksela y-tego wiersza */
    uchar *p = img.scanLine(y);

    /* Kolorujemy x-ty piksel w y-tym wierszu */
    p[x*4] = b;
    p[x*4+1] = g;
    p[x*4+2] = r;
    p[x*4+3] = 255;
}

void Ekran::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(50, 50, 50));
    p.drawImage(0, 0, img);
    update();
}

/* Czyszczenie ekranu */
void Ekran::clearWindow() {
    for(int i=0; i<height(); i++) {
        uchar *p = img.scanLine(i);
        for(int j=0; j<width(); j++) {
            if(p[j*4+2] != 255) {
                p[j*4] = 0;
                p[j*4+1] = 0;
                p[j*4+2] = 0;
                p[j*4+3] = 255;
            }
        }
    }
}

/* Rozpoczecie rysowania odcinka */
void Ekran::mousePressEvent(QMouseEvent *e) {
    /* Pobierz wspolrzedne, zaokraglij do liczby calkowitej */
    QPointF pt = e->position();
    x0 = floor(pt.x());
    y0 = floor(pt.y());
}

/* Ruszanie myszą - rysowanie tymczasowego odcinka */
void Ekran::mouseMoveEvent(QMouseEvent *e) {
    QPointF pt = e->position();
    x1 = floor(pt.x());
    y1 = floor(pt.y());
    clearWindow();
    rysuj(false);
    update();
}

/* Puszczenie myszy - narysowanie odcinka */
void Ekran::mouseReleaseEvent(QMouseEvent *e) {
    QPointF pt = e->position();
    x1 = floor(pt.x());
    y1 = floor(pt.y());
    rysuj(true);
    update();
}

double wspolczynnikKierunkowy(int x0, int x1, int y0, int y1) {
    return (double) ((y1 - y0) / (double) (x1 - x0));
}

void Ekran::rysuj(bool permanent) {
    if(x1 != x0) {
        double m = wspolczynnikKierunkowy(x0, x1, y0, y1);
        if(abs(m) > 1) {
            /* Kat nachylenia > 45 stopni - zamieniamy kolejnosc wspolrzednych w obu punktach */
            double x = x0;
            if(y1 > y0) {
                for(y=y0; y<=y1; y++) {
                    if(permanent) wstawPixel((int) floor(x), y, 255, 255, 255);
                    else wstawPixel((int) floor(x), y, 254, 255, 255);

                    x += (double) 1/m;
                }
            }
            else {
                for(y=y0; y>=y1; y--) {
                    if(permanent) wstawPixel((int) floor(x), y, 255, 255, 255);
                    else wstawPixel((int) floor(x), y, 254, 255, 255);

                    x -= (double) 1/m;
                }
            }
        }
        else {
            double y = y0;
            if(x1 > x0) {
                for(x=x0; x<=x1; x++) {
                    if(permanent) wstawPixel(x, (int) floor(y+0.5), 255, 255, 255);
                    else wstawPixel(x, (int) floor(y+0.5), 254, 255, 255);

                    y += m;
                }
            }
            else {
                for(x=x0; x>=x1; x--) {
                    if(permanent) wstawPixel(x, (int) floor(y+0.5), 255, 255, 255);
                    else wstawPixel(x, (int) floor(y+0.5), 254, 255, 255);

                    y -= m;
                }
            }
        }
    }
    else {
        /* Pionowy odcinek (rownanie x = a) */
        if(y1 > y0) {
            for(y=y0; y<=y1; y++) {
                if(permanent) wstawPixel(x0, (int) floor(y+0.5), 255, 255, 255);
                else wstawPixel(x0, (int) floor(y+0.5), 254, 255, 255);
            }
        }
        else {
            for(y=y1; y<=y0; y++) {
                if(permanent) wstawPixel(x0, (int) floor(y+0.5), 255, 255, 255);
                else wstawPixel(x0, (int) floor(y+0.5), 254, 255, 255);
            }
        }
    }

}


#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<cmath>

#include<QPainter>
#include<QPaintEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /* Setup UI */
    textureImg = new QImage("D:\\flower.jpg");
    blackImg = new QImage(textureImg->width(), textureImg->height(), QImage::Format_RGB32);

    textureTriangle = new Triangle();
    blackTriangle = new Triangle();

    currentModeForTexture = 0;
    currentModeForBlackImg = 0;

    textureTriangleVerticesAdded = 0;
    blackTriangleVerticesAdded = 0;
}

void MainWindow::texturing() {
    int i, j;

    /* Dla kazdego punktu czarnego trojkata obliczamy wspolrzedne barycentryczne */
    for(i=0; i<blackImg->height(); i++) {
        for(j=textureImg->width(); j<textureImg->width()+blackImg->width(); j++) {
            barycentricCoordinates(*blackTriangle, *new Point(j, i));
        }
    }
}

void MainWindow::barycentricCoordinates(Triangle triangle, Point p) {
    int x = p.x, y = p.y;
    int x_a = triangle.a.x, y_a = triangle.a.y;
    int x_b = triangle.b.x, y_b = triangle.b.y;
    int x_c = triangle.c.x, y_c = triangle.c.y;
    float u, v, w;
    int x_t, y_t;

    v = (float) (((x - x_a) * (y_c - y_a) - (y - y_a) * (x_c - x_a)))
            /
            (float) (((x_b - x_a) * (y_c - y_a) - (y_b - y_a) * (x_c - x_a)));

    w = (float) (((x_b - x_a) * (y - y_a) - (y_b - y_a) * (x - x_a)))
            /
            (float) (((x_b - x_a) * (y_c - y_a) - (y_b - y_a) * (x_c - x_a)));
    u = 1 - v - w;

   /* Jesli punkt znajduje sie wewnatrz czarnego trojkata to go zamaluj */
   if((u > 0)&&(v > 0)&&(w > 0)&&(u < 1)&&(v < 1)&&(w < 1)) {
       /* Obliczamy wspolrzedne (x_t, y_t) punktu P_t na teksturze */
       x_t = floor(u * textureTriangle->a.x + v * textureTriangle->b.x + w * textureTriangle->c.x);
       y_t = floor(u * textureTriangle->a.y + v * textureTriangle->b.y + w * textureTriangle->c.y);

       /* Kolorujemy punkt P wartoscia punktu P_t */
       uchar *ptr = blackImg->scanLine(y);
       uchar *texturePtr = textureImg->scanLine(y_t);

       ptr[4*x] = texturePtr[4*x_t];
       ptr[4*x + 1] = texturePtr[4*x_t + 1];
       ptr[4*x + 2] = texturePtr[4*x_t + 2];
       ptr[4*x + 3] = texturePtr[4*x_t + 3];
   }
}

void MainWindow::mousePressEvent(QMouseEvent *e) {
    QPointF position = e->position();
    int x = floor(position.x());
    int y = floor(position.y());

    if((x < 12)||(y < 12)||(x >= textureImg->width()*2-12)||(y >= textureImg->height()-12)) return;

    Point *pointToAdd = new Point(x, y);

    if(x < textureImg->width()) {
        if(currentModeForTexture == 0) {
            /* Dodajemy wierzcholek na teksturze */
            if(textureTriangleVerticesAdded == 0) {
                textureTriangle->a = *pointToAdd;
                drawPoint(*pointToAdd, true);
            }
            else if(textureTriangleVerticesAdded == 1) {
                textureTriangle->b = *pointToAdd;
                drawPoint(*pointToAdd, true);
            }
            else if(textureTriangleVerticesAdded == 2) {
                textureTriangle->c = *pointToAdd;
                drawPoint(*pointToAdd, true);

                /* Rysujemy boki trojkata */
                drawTriangle(textureTriangle->a, textureTriangle->b, textureTriangle->c, true);

                if(blackTriangleVerticesAdded > 2) {
                    texturing();
                }
            }
            else {
                detectClosestVertice(*pointToAdd, true);

                currentModeForTexture = 1; /* Tryb przesuwania */
            }
            textureTriangleVerticesAdded++;
        }
        else {
            /* Przesywamy wierzchoolek na teksturze */
            detectClosestVertice(*pointToAdd, true);
        }
    }
    else {
        if(currentModeForBlackImg == 0) {
            /* Dodajemy wierzcholek na czarnym plotnie */
            if(blackTriangleVerticesAdded == 0) {
                blackTriangle->a = *pointToAdd;
                drawPoint(*pointToAdd, false);
            }
            else if(blackTriangleVerticesAdded == 1) {
                blackTriangle->b = *pointToAdd;
                drawPoint(*pointToAdd, false);
            }
            else if(blackTriangleVerticesAdded == 2) {
                blackTriangle->c = *pointToAdd;
                drawPoint(*pointToAdd, false);

                /* Rysujemy boki trojkata */
                drawTriangle(blackTriangle->a, blackTriangle->b, blackTriangle->c, false);

                if(textureTriangleVerticesAdded > 2) {
                    texturing();
                }
            }
            else {
                detectClosestVertice(*pointToAdd, false);

                currentModeForBlackImg = 1; /* Tryb przesuwania */  
            }
            blackTriangleVerticesAdded++;
        }
        else {
            /* Przesuwamy wierzcholek na czarnej planszy */
            detectClosestVertice(*pointToAdd, false);
        }
    }
}

void MainWindow::detectClosestVertice(Point p, bool texture) {
    int i, indexOfPointToMove;
    int x = p.x, y = p.y;
    float minD = 1000000, d;
    Point currentVertice;
    QList<Point> vertices;

    if(texture) {
        vertices.append(textureTriangle->a);
        vertices.append(textureTriangle->b);
        vertices.append(textureTriangle->c);
    }
    else {
        vertices.append(blackTriangle->a);
        vertices.append(blackTriangle->b);
        vertices.append(blackTriangle->c);
    }

    for(i=0; i<vertices.size(); i++) {
        currentVertice = vertices.at(i);
        d = 0;
        d = std::pow((x - currentVertice.x), 2) + std::pow((y - currentVertice.y), 2);
        if(d < minD) {
            indexOfPointToMove = i;
            minD = d;
        }
    }

    if(texture) indexOfTexturePointToMove = indexOfPointToMove;
    else indexOfBlackImgPointToMove = indexOfPointToMove;
}

void MainWindow::drawTriangle(Point a, Point b, Point c, bool texture) {
    drawLine(a, b, texture);
    drawLine(b, c, texture);
    drawLine(c, a, texture);
}

void MainWindow::mouseMoveEvent(QMouseEvent *e) {
    QPointF position = e->position();
    int x = floor(position.x());
    int y = floor(position.y());
    Point *newPoint = new Point(x, y);

    if((x < 12)||(y < 12)||(x >= textureImg->width()*2-12)||(y >= textureImg->height()-12)) return;

    if(currentModeForTexture != 0) {
        if(x < textureImg->width()) {
            /* Przesuwamy po teksturze */
            if(indexOfTexturePointToMove == 0) {
                textureTriangle->a = *newPoint;
            }
            else if(indexOfTexturePointToMove == 1) {
                textureTriangle->b = *newPoint;
            }
            else {
                textureTriangle->c = *newPoint;
            }

            clearTexture();

            drawPoint(textureTriangle->a, true);
            drawPoint(textureTriangle->b, true);
            drawPoint(textureTriangle->c, true);

            drawTriangle(textureTriangle->a, textureTriangle->b, textureTriangle->c, true);
        }
    }

    if(currentModeForBlackImg != 0) {
        if(x > textureImg->width()) {
            /* Przesuwamy po czarnej planszy */
            if(indexOfBlackImgPointToMove == 0) {
                blackTriangle->a = *newPoint;
            }
            else if(indexOfBlackImgPointToMove == 1) {
                blackTriangle->b = *newPoint;
            }
            else {
                blackTriangle->c = *newPoint;
            }


            clearBlackImg();

            drawPoint(blackTriangle->a, false);
            drawPoint(blackTriangle->b, false);
            drawPoint(blackTriangle->c, false);

            drawTriangle(blackTriangle->a, blackTriangle->b, blackTriangle->c, false);
        }
    }

    if((textureTriangleVerticesAdded > 2)&&(blackTriangleVerticesAdded > 2)) texturing();
}

void MainWindow::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.fillRect(0, 0, width(), height(), QColor(50, 50, 50));
    p.drawImage(0, 0, *textureImg);
    p.drawImage(textureImg->width(), 0, *blackImg);
    update();
}

void MainWindow::clearTexture() {
    textureImg = new QImage("D:\\flower.jpg");
    update();
}

void MainWindow::clearBlackImg() {
   blackImg = new QImage(textureImg->width(), textureImg->height(), QImage::Format_RGB32);
   update();
}

void MainWindow::drawPixel(Point p, bool texture) {
    int x = p.x;
    int y = p.y;

    if((x < 0)||(y < 0)||(x > textureImg->width() * 2)||(y > textureImg->height())) return;

    uchar *ptr;
    if(texture) ptr = textureImg->scanLine(y);
    else ptr = blackImg->scanLine(y);

    ptr[4*x] = 0;
    ptr[4*x+1] = 255;
    ptr[4*x+2] = 0;
    ptr[4*x+3] = 255;
}

void MainWindow::drawPoint(Point p, bool texture) {
    if((p.x < 0)||(p.y < 0)||(p.x >= textureImg->width()*2)||(p.y >= textureImg->height())) return;

    int i, j;
    int x = p.x;
    int y = p.y;

    uchar *ptr, *ptr2, *ptr3, *ptr4, *ptr5, *ptr11, *ptr12, *ptr13, *ptr14, *ptr15;

    if(texture) {
        ptr11 = textureImg->scanLine(y-1);
        ptr12 = textureImg->scanLine(y-2);
        ptr13 = textureImg->scanLine(y-3);
        ptr14 = textureImg->scanLine(y-4);
        ptr15 = textureImg->scanLine(y-5);
        ptr = textureImg->scanLine(y);
        ptr2 = textureImg->scanLine(y+1);
        ptr3 = textureImg->scanLine(y+2);
        ptr4 = textureImg->scanLine(y+3);
        ptr5 = textureImg->scanLine(y+4);
    }
    else {
        ptr11 = blackImg->scanLine(y-1);
        ptr12 = blackImg->scanLine(y-2);
        ptr13 = blackImg->scanLine(y-3);
        ptr14 = blackImg->scanLine(y-4);
        ptr15 = blackImg->scanLine(y-5);
        ptr = blackImg->scanLine(y);
        ptr2 = blackImg->scanLine(y+1);
        ptr3 = blackImg->scanLine(y+2);
        ptr4 = blackImg->scanLine(y+3);
        ptr5 = blackImg->scanLine(y+4);
    }

    QList<uchar> pointers;
    pointers.append(*ptr);
    pointers.append(*ptr2);
    pointers.append(*ptr3);
    pointers.append(*ptr4);
    pointers.append(*ptr5);
    pointers.append(*ptr11);
    pointers.append(*ptr12);
    pointers.append(*ptr13);
    pointers.append(*ptr14);
    pointers.append(*ptr15);

    /* Piec poziomych i pionowych pikseli */
    for(i=x-5; i<x+5; i++) {
        ptr[4*i] = 0;
        ptr[4*i+1] = 255;
        ptr[4*i+2] = 0;
        ptr[4*i+3] = 255;

        ptr2[4*i] = 0;
        ptr2[4*i+1] = 255;
        ptr2[4*i+2] = 0;
        ptr2[4*i+3] = 255;

        ptr3[4*i] = 0;
        ptr3[4*i+1] = 255;
        ptr3[4*i+2] = 0;
        ptr3[4*i+3] = 255;

        ptr4[4*i] = 0;
        ptr4[4*i+1] = 255;
        ptr4[4*i+2] = 0;
        ptr4[4*i+3] = 255;

        ptr5[4*i] = 0;
        ptr5[4*i+1] = 255;
        ptr5[4*i+2] = 0;
        ptr5[4*i+3] = 255;

        ptr11[4*i] = 0;
        ptr11[4*i+1] = 255;
        ptr11[4*i+2] = 0;
        ptr11[4*i+3] = 255;

        ptr12[4*i] = 0;
        ptr12[4*i+1] = 255;
        ptr12[4*i+2] = 0;
        ptr12[4*i+3] = 255;

        ptr13[4*i] = 0;
        ptr13[4*i+1] = 255;
        ptr13[4*i+2] = 0;
        ptr13[4*i+3] = 255;

        ptr14[4*i] = 0;
        ptr14[4*i+1] = 255;
        ptr14[4*i+2] = 0;
        ptr14[4*i+3] = 255;

        ptr15[4*i] = 0;
        ptr15[4*i+1] = 255;
        ptr15[4*i+2] = 0;
        ptr15[4*i+3] = 255;
    }

}

double MainWindow::slope(int x0, int x1, int y0, int y1) {
    return (double) ((y1 - y0) / (double) (x1 - x0));
}

void MainWindow::drawLine(Point p1, Point p2, bool texture) {
    int x0 = p1.x;
    int y0 = p1.y;
    int x1 = p2.x;
    int y1 = p2.y;
    if(x1 != x0) {
        double m = slope(x0, x1, y0, y1);
        if(abs(m) > 1) {
            /* Kat nachylenia > 45 stopni - zamieniamy kolejnosc wspolrzednych w obu punktach */
            double x = x0;
            int y;
            if(y1 > y0) {
                for(y=y0; y<=y1; y++) {
                    drawPixel(*new Point((int) floor(x), y), texture);

                    x += (double) 1/m;
                }
            }
            else {
                for(y=y0; y>=y1; y--) {
                    drawPixel(*new Point((int) floor(x), y), texture);

                    x -= (double) 1/m;
                }
            }
        }
        else {
            int x;
            double y = y0;
            if(x1 > x0) {
                for(x=x0; x<=x1; x++) {
                    drawPixel(*new Point(x, (int) floor(y+0.5)), texture);

                    y += m;
                }
            }
            else {
                for(x=x0; x>=x1; x--) {
                    drawPixel(*new Point(x, (int) floor(y+0.5)), texture);

                    y -= m;
                }
            }
        }
    }
    else {
        /* Pionowy odcinek (rownanie x = a) */
        int y;
        if(y1 > y0) {
            for(y=y0; y<=y1; y++) {
                 drawPixel(*new Point(x0, (int) floor(y+0.5)), texture);
            }
        }
        else {
            for(y=y1; y<=y0; y++) {
                drawPixel(*new Point(x0, (int) floor(y+0.5)), texture);
            }
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include<QMainWindow>
#include<QImage>

#include "triangle.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QImage *textureImg, *blackImg;
    Triangle *textureTriangle, *blackTriangle;
    Point pointToMove;
    int currentModeForTexture, currentModeForBlackImg;
    int textureTriangleVerticesAdded, blackTriangleVerticesAdded;
    int indexOfTexturePointToMove, indexOfBlackImgPointToMove;

    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *e);
    void drawPoint(Point p, bool texture);
    void clearTexture();
    void clearBlackImg();
    void mouseMoveEvent(QMouseEvent *e);
    void drawLine(Point p1, Point p2);
    double slope(int x0, int x1, int y0, int y1);
    void drawLine(Point p1, Point p2, bool texture);
    void drawTriangle(Point a, Point b, Point c);
    void drawPixel(Point p, bool texture);
    void drawTriangle(Point a, Point b, Point c, bool texture);
    void detectClosestVertice(Point p, bool texture);
    void barycentricCoordinates(Triangle triangle, Point p);
    void texturing();
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

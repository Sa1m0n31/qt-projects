#include "triangle.h"

Triangle::Triangle()
{

}

Triangle::Triangle(Point a, Point b, Point c) {
    this->a = a;
    this->b = b;
    this->c = c;
}

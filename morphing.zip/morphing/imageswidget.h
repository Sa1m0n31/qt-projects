#ifndef IMAGESWIDGET_H
#define IMAGESWIDGET_H

#include <QWidget>
#include "point.h"
#include "triangle.h"

class ImagesWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ImagesWidget(QWidget *parent = nullptr);

    QImage *img1, *img2;
    int pointsAddedImg1, pointsAddedImg2;
    Point verticesImg1[3], verticesImg2[3];
    Point currentPointToMove;
    int currentIndexOfPointToMove;
    Triangle *triangle1, *triangle2;

    void paintEvent(QPaintEvent *event);
    void changeImage(int v);
    int currentImg;
    void mousePressEvent(QMouseEvent *event);
    void drawPoint(Point p, bool isImg1);
    void mouseMoveEvent(QMouseEvent *event);
    void detectClosestVertice(Point p, bool isImg1);
    void detectClosestVertice(Point p);
    double slope(int x0, int x1, int y0, int y1);
    void drawLine(Point p1, Point p2);
    void drawPixel(Point p);
    void drawTriangle();
    void drawPoint(Point p);
    void clearImg();
    void clearAndDrawImg(Point p);
signals:

};

#endif // IMAGESWIDGET_H

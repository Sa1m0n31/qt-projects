#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "windows.h"
#include "imageswidget.h"
#include "triangle.h"

#include<QPainter>
#include<QLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    changeImage = this->ui->changeImage;
    changeSnapshot = this->ui->changeSnapshot;
    imagesWidget = new ImagesWidget();
    resultWidget = new ResultWidget();
    changeImage->setRange(0, 1);
    changeSnapshot->setRange(0, 10);

    this->layout()->addWidget(imagesWidget);
    this->layout()->addWidget(resultWidget);

    this->resize(1000, 800);
    currentSnapshot = 0;

    QObject::connect(changeImage, SIGNAL(valueChanged(int)), SLOT(handleChangeImage(int)));
    QObject::connect(changeSnapshot, SIGNAL(valueChanged(int)), SLOT(handleChangeSnapshot(int)));
}

void MainWindow::texturing(int n) {
    int i, j, imgToRemember;
    Point p(-1, -1);

    resultWidget->clearWidget();

    /* Usuwamy zielone krawedzie */
    imgToRemember = imagesWidget->currentImg;
    imagesWidget->currentImg = 0;
    imagesWidget->clearImg();
    imagesWidget->currentImg = 1;
    imagesWidget->clearImg();

    /* Dla kazdego punktu czarnego trojkata obliczamy wspolrzedne barycentryczne */
    for(i=0; i<resultWidget->height(); i++) {
        for(j=0; j<resultWidget->width(); j++) {
            barycentricCoordinates(Point(j, i), n);
        }
    }

    /* Rysujemy z powrotem zielone krawedzie */
    imagesWidget->currentImg = 0;
    imagesWidget->clearAndDrawImg(p);
    imagesWidget->currentImg = 1;
    imagesWidget->clearAndDrawImg(p);

    imagesWidget->currentImg = imgToRemember;

    update();
}

void MainWindow::barycentricCoordinates(Point p, int n) {
    int x = p.x, y = p.y;
    float u, v, w;
    int x_t, y_t;

    /* Obliczamy wspolrzedne czarnego trojkata na podstawie klatki - n */
    int x_a = (1 - (float) n / (float) 10) * imagesWidget->verticesImg1[0].x + (float) n / (float) 10 * imagesWidget->verticesImg2[0].x;
    int x_b = (1 - (float) n / (float) 10) * imagesWidget->verticesImg1[1].x + (float) n / (float) 10 * imagesWidget->verticesImg2[1].x;
    int x_c = (1 - (float) n / (float) 10) * imagesWidget->verticesImg1[2].x + (float) n / (float) 10 * imagesWidget->verticesImg2[2].x;
    int y_a = (1 - (float) n / (float) 10) * imagesWidget->verticesImg1[0].y + (float) n / (float) 10 * imagesWidget->verticesImg2[0].y;
    int y_b = (1 - (float) n / (float) 10) * imagesWidget->verticesImg1[1].y + (float) n / (float) 10 * imagesWidget->verticesImg2[1].y;
    int y_c = (1 - (float) n / (float) 10) * imagesWidget->verticesImg1[2].y + (float) n / (float) 10 * imagesWidget->verticesImg2[2].y;

    v = (float) (((x - x_a) * (y_c - y_a) - (y - y_a) * (x_c - x_a)))
            /
            (float) (((x_b - x_a) * (y_c - y_a) - (y_b - y_a) * (x_c - x_a)));

    w = (float) (((x_b - x_a) * (y - y_a) - (y_b - y_a) * (x - x_a)))
            /
            (float) (((x_b - x_a) * (y_c - y_a) - (y_b - y_a) * (x_c - x_a)));
    u = 1 - v - w;

   /* Jesli punkt znajduje sie wewnatrz czarnego trojkata to go zamaluj */
   if((u > 0)&&(v > 0)&&(w > 0)&&(u < 1)&&(v < 1)&&(w < 1)) {
       /* Obliczamy wspolrzedne (x_t, y_t) punktu P_t na teksturze */
       x_t = floor(u * x_a + v * x_b + w * x_c);
       y_t = floor(u * y_a + v * y_b + w * y_c);

       /* Kolorujemy punkt P wartoscia punktu P_t */
       uchar *ptr = resultWidget->img->scanLine(y);
       uchar *texturePtr1 = imagesWidget->img1->scanLine(y_t);
       uchar *texturePtr2 = imagesWidget->img2->scanLine(y_t);

       ptr[4*x] = (1 - (float) n / (float) 10) * texturePtr1[4*x_t] + (float) n / (float) 10 * texturePtr2[4*x_t];
       ptr[4*x + 1] = (1 - (float) n / (float) 10) * texturePtr1[4*x_t+1] + (float) n / (float) 10 * texturePtr2[4*x_t+1];
       ptr[4*x + 2] = (1 - (float) n / (float) 10) * texturePtr1[4*x_t+2] + (float) n / (float) 10 * texturePtr2[4*x_t+2];
       ptr[4*x + 3] = (1 - (float) n / (float) 10) * texturePtr1[4*x_t+3] + (float) n / (float) 10 * texturePtr2[4*x_t+3];
   }
}


void MainWindow::handleChangeImage(int v) {
    imagesWidget->changeImage(v);
    update();
}

void MainWindow::handleChangeSnapshot(int v) {
    currentSnapshot = v;

    if((imagesWidget->pointsAddedImg1 == 3)&&(imagesWidget->pointsAddedImg2 == 3)) {
       texturing(v);
    }
}

void MainWindow::paintEvent(QPaintEvent *event) {
    QPainter p(this);
    update();
}

MainWindow::~MainWindow()
{
    delete ui;
}


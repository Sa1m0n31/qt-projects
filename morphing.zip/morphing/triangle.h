#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "point.h"


class Triangle
{
public:
    Triangle();
    Triangle(Point a, Point b, Point c);
    Point a, b, c;
};

#endif // TRIANGLE_H

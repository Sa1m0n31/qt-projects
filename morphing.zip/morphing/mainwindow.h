#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include<QMainWindow>
#include<QSlider>
#include<QImage>
#include<QPushButton>

#include "imageswidget.h"
#include "resultwidget.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    ImagesWidget *imagesWidget;
    ResultWidget *resultWidget;
    QImage *img1, *img2;
    QSlider *changeImage, *changeSnapshot;
    int currentSnapshot;
    Point triangle1[3], triangle2[3];

    void paintEvent(QPaintEvent *event);
    void texturing(int n);
    void barycentricCoordinates(Point p, int n);
public slots:
    void handleChangeImage(int v);
    void handleChangeSnapshot(int v);
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

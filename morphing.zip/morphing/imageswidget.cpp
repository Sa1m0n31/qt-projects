#include "imageswidget.h"

#include<QImage>
#include<QPainter>
#include<QMouseEvent>

#include "point.h"

ImagesWidget::ImagesWidget(QWidget *parent) : QWidget(parent)
{
    img1 = new QImage("D:\\lebron-james.png");
    img2 = new QImage("D:\\kevin-durant.jpg");

    currentImg = 0;
    pointsAddedImg1 = 0;
    pointsAddedImg2 = 0;

    this->resize(500, 500);
}

void ImagesWidget::mousePressEvent(QMouseEvent *event) {
    QPointF position = event->position();
    int x = floor(position.x());
    int y = floor(position.y());
    Point point(x, y);

    if(currentImg == 0) {
        if(pointsAddedImg1 < 3) {
            drawPoint(point);
            verticesImg1[pointsAddedImg1] = point;
            pointsAddedImg1++;
        }
        else {
            detectClosestVertice(point);
        }


        if(pointsAddedImg1 == 3) drawTriangle();
    }
    else {
        if(pointsAddedImg2 < 3) {
            drawPoint(point);
            verticesImg2[pointsAddedImg2] = point;
            pointsAddedImg2++;
        }
        else {
            detectClosestVertice(point);
        }

        if(pointsAddedImg2 == 3) drawTriangle();
    }
}

void ImagesWidget::detectClosestVertice(Point p) {
    int i;
    Point arrayOfVertices[3];
    double d, minD = 1000000;

    if(currentImg == 0) {
        for(i=0; i<3; i++) {
             d = std::pow((p.x - verticesImg1[i].x), 2) + std::pow((p.y - verticesImg1[i].y), 2);
             if(d < minD) {
                 currentIndexOfPointToMove = i;
                 minD = d;
             }
        }
    }
    else {
        for(i=0; i<3; i++) {
             d = std::pow((p.x - verticesImg2[i].x), 2) + std::pow((p.y - verticesImg2[i].y), 2);
             if(d < minD) {
                currentIndexOfPointToMove = i;
                minD = d;
             }
        }
    }
}

void ImagesWidget::mouseMoveEvent(QMouseEvent *event) {
    QPointF position = event->position();
    int x = floor(position.x());
    int y = floor(position.y());
    Point p(x, y);

    clearAndDrawImg(p);
}

void ImagesWidget::clearAndDrawImg(Point p) {
    if(currentImg == 0) {
        if(pointsAddedImg1 >= 3) {
            clearImg();
            if(p.x > -1) verticesImg1[currentIndexOfPointToMove] = p;
            drawPoint(verticesImg1[0]);
            drawPoint(verticesImg1[1]);
            drawPoint(verticesImg1[2]);
            drawTriangle();
        }
    }
    else {
        if(pointsAddedImg2 >= 3) {
            clearImg();
            if(p.x > -1) verticesImg2[currentIndexOfPointToMove] = p;
            drawPoint(verticesImg2[0]);
            drawPoint(verticesImg2[1]);
            drawPoint(verticesImg2[2]);
            drawTriangle();
        }
    }
}

void ImagesWidget::clearImg() {
    if(currentImg == 0) {
        img1 = new QImage("D:\\lebron-james.png");
    }
    else {
        img2 = new QImage("D:\\kevin-durant.jpg");
    }
    update();
}

void ImagesWidget::drawTriangle() {
    if(currentImg == 0) {
        drawLine(verticesImg1[0], verticesImg1[1]);
        drawLine(verticesImg1[1], verticesImg1[2]);
        drawLine(verticesImg1[2], verticesImg1[0]);
    }
    else {
        drawLine(verticesImg2[0], verticesImg2[1]);
        drawLine(verticesImg2[1], verticesImg2[2]);
        drawLine(verticesImg2[2], verticesImg2[0]);
    }
}

void ImagesWidget::drawPixel(Point p) {
    int x = p.x;
    int y = p.y;

    if((x < 0)||(y < 0)||(x > 500)||(y > 500)) return;

    uchar *ptr;
    if(currentImg == 0) ptr = img1->scanLine(y);
    else ptr = img2->scanLine(y);

    ptr[4*x] = 0;
    ptr[4*x+1] = 255;
    ptr[4*x+2] = 0;
    ptr[4*x+3] = 255;
}

double ImagesWidget::slope(int x0, int x1, int y0, int y1) {
    return (double) ((y1 - y0) / (double) (x1 - x0));
}

void ImagesWidget::drawLine(Point p1, Point p2) {
    int x0 = p1.x;
    int y0 = p1.y;
    int x1 = p2.x;
    int y1 = p2.y;
    if(x1 != x0) {
        double m = slope(x0, x1, y0, y1);
        if(abs(m) > 1) {
            /* Kat nachylenia > 45 stopni - zamieniamy kolejnosc wspolrzednych w obu punktach */
            double x = x0;
            int y;
            if(y1 > y0) {
                for(y=y0; y<=y1; y++) {
                    drawPixel(Point((int) floor(x), y));

                    x += (double) 1/m;
                }
            }
            else {
                for(y=y0; y>=y1; y--) {
                    drawPixel(Point((int) floor(x), y));

                    x -= (double) 1/m;
                }
            }
        }
        else {
            int x;
            double y = y0;
            if(x1 > x0) {
                for(x=x0; x<=x1; x++) {
                    drawPixel(Point(x, (int) floor(y+0.5)));

                    y += m;
                }
            }
            else {
                for(x=x0; x>=x1; x--) {
                    drawPixel(Point(x, (int) floor(y+0.5)));

                    y -= m;
                }
            }
        }
    }
    else {
        /* Pionowy odcinek (rownanie x = a) */
        int y;
        if(y1 > y0) {
            for(y=y0; y<=y1; y++) {
                 drawPixel(Point(x0, (int) floor(y+0.5)));
            }
        }
        else {
            for(y=y1; y<=y0; y++) {
                drawPixel(Point(x0, (int) floor(y+0.5)));
            }
        }
    }
}



void ImagesWidget::drawPoint(Point p) {
    if((p.x < 0)||(p.y < 0)||(p.x >= 500)||(p.y >= 500)) return;

    int i, j;
    int x = p.x;
    int y = p.y;

    uchar *ptr, *ptr2, *ptr3, *ptr4, *ptr5, *ptr11, *ptr12, *ptr13, *ptr14, *ptr15;

    if(currentImg == 0) {
        ptr11 = img1->scanLine(y-1);
        ptr12 = img1->scanLine(y-2);
        ptr13 = img1->scanLine(y-3);
        ptr14 = img1->scanLine(y-4);
        ptr15 = img1->scanLine(y-5);
        ptr = img1->scanLine(y);
        ptr2 = img1->scanLine(y+1);
        ptr3 = img1->scanLine(y+2);
        ptr4 = img1->scanLine(y+3);
        ptr5 = img1->scanLine(y+4);
    }
    else {
        ptr11 = img2->scanLine(y-1);
        ptr12 = img2->scanLine(y-2);
        ptr13 = img2->scanLine(y-3);
        ptr14 = img2->scanLine(y-4);
        ptr15 = img2->scanLine(y-5);
        ptr = img2->scanLine(y);
        ptr2 = img2->scanLine(y+1);
        ptr3 = img2->scanLine(y+2);
        ptr4 = img2->scanLine(y+3);
        ptr5 = img2->scanLine(y+4);
    }

    QList<uchar> pointers;
    pointers.append(*ptr);
    pointers.append(*ptr2);
    pointers.append(*ptr3);
    pointers.append(*ptr4);
    pointers.append(*ptr5);
    pointers.append(*ptr11);
    pointers.append(*ptr12);
    pointers.append(*ptr13);
    pointers.append(*ptr14);
    pointers.append(*ptr15);

    /* Piec poziomych i pionowych pikseli */
    for(i=x-5; i<x+5; i++) {
        ptr[4*i] = 0;
        ptr[4*i+1] = 255;
        ptr[4*i+2] = 0;
        ptr[4*i+3] = 255;

        ptr2[4*i] = 0;
        ptr2[4*i+1] = 255;
        ptr2[4*i+2] = 0;
        ptr2[4*i+3] = 255;

        ptr3[4*i] = 0;
        ptr3[4*i+1] = 255;
        ptr3[4*i+2] = 0;
        ptr3[4*i+3] = 255;

        ptr4[4*i] = 0;
        ptr4[4*i+1] = 255;
        ptr4[4*i+2] = 0;
        ptr4[4*i+3] = 255;

        ptr5[4*i] = 0;
        ptr5[4*i+1] = 255;
        ptr5[4*i+2] = 0;
        ptr5[4*i+3] = 255;

        ptr11[4*i] = 0;
        ptr11[4*i+1] = 255;
        ptr11[4*i+2] = 0;
        ptr11[4*i+3] = 255;

        ptr12[4*i] = 0;
        ptr12[4*i+1] = 255;
        ptr12[4*i+2] = 0;
        ptr12[4*i+3] = 255;

        ptr13[4*i] = 0;
        ptr13[4*i+1] = 255;
        ptr13[4*i+2] = 0;
        ptr13[4*i+3] = 255;

        ptr14[4*i] = 0;
        ptr14[4*i+1] = 255;
        ptr14[4*i+2] = 0;
        ptr14[4*i+3] = 255;

        ptr15[4*i] = 0;
        ptr15[4*i+1] = 255;
        ptr15[4*i+2] = 0;
        ptr15[4*i+3] = 255;
    }

}

void ImagesWidget::changeImage(int v) {
    currentImg = v;
    update();
}

void ImagesWidget::paintEvent(QPaintEvent *event) {
    QPainter p(this);
    if(currentImg == 0) {
        p.drawImage(0, 0, *img1);
    }
    else {
        p.drawImage(0, 0, *img2);
    }
    update();
}
